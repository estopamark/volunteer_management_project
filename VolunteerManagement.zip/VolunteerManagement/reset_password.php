<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="reset_password.css" />
    <title>Reset Password</title>

    <?php
    session_start(); // Start the session

    require('db.php');

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $password = $_POST['password'];
        $confirm_password = $_POST['confirmPassword'];

        // Validate passwords
        if ($password != $confirm_password) {
            echo "Passwords do not match.";
        } else {
            // Reset the user's password in the database
            if (isset($_SESSION['reset_email'])) {
                $email = $_SESSION['reset_email'];
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                // Update password in volunteers table
                $query_volunteers = "UPDATE volunteers SET password='$hashed_password' WHERE email='$email'";
                $result_volunteers = mysqli_query($conn, $query_volunteers);

                // Update password in manager table if not found in volunteers table
                if (mysqli_affected_rows($conn) == 0) {
                    $query_manager = "UPDATE manager SET password='$hashed_password' WHERE email='$email'";
                    $result_manager = mysqli_query($conn, $query_manager);
                }

                if ($result_volunteers || $result_manager) {
                    // Clear session variables
                    unset($_SESSION['reset_email']);
                    unset($_SESSION['reset_otp']);

                    echo '<p style="color:white;">Password reset successfully. You can now <a href=\'index.php\'>login</a> with your new password.</p>';

                    exit();
                } else {
                    echo "Error updating password: " . mysqli_error($con);
                }
            } else {
                echo "Reset email not found in session.";
            }
        }
    }
    ?>
</head>

<body>

    <form method="post">
        <h2>Reset Password</h2>
        <!-- Password -->
        <label>New Password</label>
        <br>
        <input type="password" class="login-input" name="password" id="password" placeholder="New Password" onkeyup="validatePassword(this); validateForm()" required /><br>    
        <div class="show-password">
            <input type="checkbox" onclick="togglePasswordVisibility('password')"> Show Password
            <div class="password-info" id="password_info"></div>
        </div><br>

        <!-- Confirm Password -->
        <label>Confirm Password</label>
        <br>
        <input type="password" class="login-input" name="confirmPassword" id="confirmPassword" placeholder="Confirm Password" onkeyup="checkPasswordMatch(); validateForm()" required /><br>
        <div class="show-password">
            <input type="checkbox" onclick="togglePasswordVisibility('confirmPassword')"> Show Password
            <div class="password-info" id="confirm_password_info"></div>
        </div><br>

        <!-- Submit Button -->
        <input type="submit" value="Continue" id="submit_button" disabled>
    </form>

    <script type="text/javascript">

        // JavaScript function to toggle password visibility
        function togglePasswordVisibility(inputId) {
            var passwordField = document.getElementById(inputId);
            if (passwordField.type === "password") {
                passwordField.type = "text";
            } else {
                passwordField.type = "password";
            }
        }

        // JavaScript function to validate password
        function validatePassword(passwordInput) {
            var password = passwordInput.value;
            var passwordInfo = passwordInput.parentElement.getElementsByClassName("password-info")[0];

            // Validate password rules
            var validPassword = true;
            if (password.length < 8 || password.length > 20) {
                validPassword = false;
                passwordInfo.textContent = "Password must be 8-20 characters";
            } else if (!/[!@#$%^&*()_+\-={}\[\]|:;<>?,./~]/.test(password)) {
                validPassword = false;
                passwordInfo.textContent = "At least one special character";
            } else if (!/[A-Z]/.test(password)) {
                validPassword = false;
                passwordInfo.textContent = "At least one capital letter";
            } else if (!/[0-9]/.test(password)) {
                validPassword = false;
                passwordInfo.textContent = "At least one number";
            } else {
                passwordInfo.textContent = "✓ Strong Password";
            }

            if (validPassword) {
                passwordInfo.style.color = "green";
            } else {
                passwordInfo.style.color = "red";
            }

            validateForm();
        }

        // JavaScript function to check password match
        function checkPasswordMatch() {
            var confirmPassword = document.getElementById("confirmPassword").value;
            var password = document.getElementById("password").value;
            var confirmPasswordInfo = document.getElementById("confirm_password_info");

            if (password === confirmPassword) {
                confirmPasswordInfo.textContent = "✓ Password match";
                confirmPasswordInfo.style.color = "green";
            } else {
                confirmPasswordInfo.textContent = "Password didn't match";
                confirmPasswordInfo.style.color = "red";
            }

            validateForm();
        }

        // Function to validate form before submission
        function validateForm() {
            var password = document.getElementById("password").value;
            var confirmPassword = document.getElementById("confirmPassword").value;
            var passwordInfo = document.getElementById("password_info");
            var submitButton = document.getElementById("submit_button");

            // Check if any field is empty
            if (password === "" || confirmPassword === "") {
                submitButton.disabled = true;
                return false;
            } else if (passwordInfo.textContent.trim() !== "✓ Strong Password") {
                submitButton.disabled = true;
                return false;
            } else {
                submitButton.disabled = false;
                return true;
            }
        }

    </script>

</body>

</html>
