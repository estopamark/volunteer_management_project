<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Volunteer Management System</title>
    <link rel="stylesheet" href="css/styles.css">
    <style type="text/css">
         header {
            background-color: rgba(128, 0, 128, 0.7);
            padding: 10px;
            text-align: center;
            font-size: 30px;
            backdrop-filter: blur(3px);
            box-shadow: 5px 12px 24px rgba(0, 0, 0, 0.2); /* Updated box shadow */
        }
        .h1-header {
            color: #fff;
            text-shadow: 6px 12px 18px rgba(0, 0, 0, 0.5); /* Updated text shadow */
        }
        .container {
            text-align: center;
        }
        .container-login {
            display: inline-block;
            text-align: left;
            margin-top: 30px;

            padding: 30px;
            background-color: #f2f2f2;
            border-radius: 10px;
        }
         .h1-Login {
            text-align: center; /* Center the Login label */
            text-shadow: 2px 2px 4px rgba(50, 50, 50, 0.7); /* Dark gray text shadow */
        }
    
        .forgot-password {
            
            display: inline-block; /* Adjusted to align inline with checkbox */
            vertical-align: right; /* Adjusted to align inline with checkbox */
            padding-left: 90px;
        }
        .forgot-password a {
            color: blue; /* Adjusted link color */
            text-decoration: none; /* Adjusted link decoration */
        }
    </style>
</head>
<body>
    <header>
        <h1 class="h1-header">Volunteer Management System</h1>
    </header>
    <div class="container">
        <form class="container-login" action="login.php" method="post" onsubmit="return validateForm()">
            <h1 class="h1-Login">Login</h1>
            <label for="username">Username</label>
            <input placeholder="Enter username" type="text" id="username" name="username" required><br>
            <label for="password">Password</label>
            <input placeholder="Enter password" type="password" id="password" name="password" required>
            <input type="checkbox" onclick="togglePasswordVisibility('password')"> Show Password
            <div class="forgot-password">
                <a href="forgot-password.php">Forgot your password?</a>
            </div>
            <br><br>
            <input type="submit" value="Login">
            <!-- Wrap the link in a div to apply centering styles -->
            <div class="register-link">
                <label for="login_link">Don't have an account? <a href="pages/registration_form.php">Click here to register</a></label>
            </div>
        </form>
    </div>
    <div class="container">
        <!-- Form elements -->
        <?php
        session_start();
        if (isset($_SESSION['error_message'])) {
            echo '<script>alert("' . $_SESSION['error_message'] . '");</script>';
            unset($_SESSION['error_message']); // Clear the error message
        }
        ?>
    </div>

    <script>
        function validateForm() {
            // No need to check user type
            return true; // allow form submission
        }

        function togglePasswordVisibility(fieldId) {
            var passwordField = document.getElementById(fieldId);
            if (passwordField.type === "password") {
                passwordField.type = "text";
            } else {
                passwordField.type = "password";
            }
        }
    </script>
</body>
</html>
