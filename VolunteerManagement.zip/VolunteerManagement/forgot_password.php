<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="forgot_password.css" />
    <title>Forgot Password</title>
</head>
<style>
    body {
    background-image: url(background.jpg);
    background-size: cover; /* Ensure the background image covers the entire viewport */
    backdrop-filter: blur(5px); /* Adjust the blur radius as needed */
    flex-direction: column;
    background-repeat: no-repeat;
    background-size: cover;
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
   font-family: Arial, sans-serif;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}
    label{
        margin-left: -200px;
    }
    input{
        width: 100%;
        padding: 10px;
        margin-top: 10px;
        margin-bottom: 10px;
        box-sizing: border-box;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 16px;
    }
    button{
        background-color: #4E4FEB;
        color: #fff;
        border: none;
        cursor: pointer;
        width: 100%;
  
        padding: 10px;
        margin-top: 10px;
        margin-bottom: 10px;
        border-radius: 5px;
        font-size: 16px;
    }
    button:hover{
        background-color: #0056b3;
    }
    .container input[type="submit"] {
    background-color: #4E4FEB;
    color: #fff;
    border: none;
    cursor: pointer;
}
    
</style>


<body>
    <div class="container">
        <h2>Forgot Password</h2>
        <?php
        session_start();
        require('db.php');
       
        // Function to generate OTP
        function generateOTP()
        {
            // Generate a random 6-digit OTP
            return rand(100000, 999999);
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if(isset($_POST['email'])) {
        $email = $_POST['email'];

        // Check if the email exists in the volunteers or manager table
        $query_volunteers = "SELECT * FROM volunteers WHERE email='$email'";
        $result_volunteers = mysqli_query($conn, $query_volunteers);

        $query_manager = "SELECT * FROM manager WHERE email='$email'";
        $result_manager = mysqli_query($conn, $query_manager);

        if (mysqli_num_rows($result_volunteers) > 0 || mysqli_num_rows($result_manager) > 0) {
            // Email found in either volunteers or manager table
            $row = mysqli_fetch_assoc($result_volunteers); // Assuming you only need one row for reset
            if (!$row) {
                $row = mysqli_fetch_assoc($result_manager);
            }

            // Generate and send OTP
            $otp = generateOTP();
            $_SESSION['reset_email'] = $email; // Store email in session for verification
            $_SESSION['reset_otp'] = $otp; // Store OTP in session for verification

            // Configure SMTP settings
            // Configure SMTP settings for Gmail
            ini_set("SMTP", "smtp.example.com"); // Replace smtp.example.com with your SMTP server address
            ini_set("smtp_port", "25"); // Replace 587 with your SMTP port number
            // Send OTP to email
            $to = $email;
            $subject = "Password Reset OTP";
            $message = "In order to complete the process of setting up your password, we need to verify that this email address belongs to you. \n\n Your one-time password (OTP) for resetting your password is: $otp \n\n If you didn't request this code, please disregard this email. It's possible that someone else mistakenly entered your email address.";                 
            $headers = "From: your@example.com";

            if (mail($to, $subject, $message, $headers)) {
                echo "<p>An OTP has been sent to your email. Please check your inbox and enter the OTP below.</p>";
                echo '<form id="otpForm" method="post" action="verify_otp.php">
                <label>Enter OTP:</label>
                <br>
                <input type="text" name="otp" required placeholder="Enter code">
                <br>
                <button style="background-color: rgba(128, 0, 128, 0.7); color: white;" type="submit" id="submitBtn">Continue</button>
                

                </form>';
                echo '<div id="resendContainer" style="display:none;">
                        <p>Didn’t get the code?</p>
                        <a id="resendLink" href="#" onclick="resendOTP()">Resend OTP</a>
                    </div>';
                echo '<div id="timer">30</div>';
                echo  '<script>

                    var timeLeft = 30;
                    var timer = document.getElementById("timer");
                    var countdown = setInterval(function() {
                        timeLeft--;
                        timer.textContent = timeLeft;
                        if (timeLeft <= 0) {
                            clearInterval(countdown);
                            document.getElementById("resendContainer").style.display = "block";
                            document.getElementById("timer").style.display = "none";
                        }
                    }, 1000);
                    function resendOTP() {
                        // Make an AJAX request to resend OTP
                        var xhr = new XMLHttpRequest();
                        xhr.open("POST", "resend_otp.php", true);
                        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                        xhr.onreadystatechange = function() {
                            if (xhr.readyState == 4 && xhr.status == 200) {
                                if (xhr.responseText == "success") {
                                    // OTP resend successful, restart the timer
                                    document.getElementById("resendContainer").style.display = "none";
                                    document.getElementById("timer").style.display = "block";
                                    timeLeft = 30;
                                    var countdown = setInterval(function() {
                                        timeLeft--;
                                        timer.textContent = timeLeft;
                                        if (timeLeft <= 0) {
                                            clearInterval(countdown);
                                            document.getElementById("resendContainer").style.display = "block";
                                            document.getElementById("timer").style.display = "none";
                                        }
                                    }, 1000);
                                } else {
                                    // OTP resend failed
                                    alert("Failed to resend OTP. Please try again later.");
                                }
                            }
                        };
                        xhr.send();
                    }
                </script>';
            } else {
                echo "<p>Failed to send OTP. Please try again later.</p>";
            }

            // Hide the email input form
            echo '<style>.email-form { display: none; }</style>';
        } else {
            echo "<p style='color: red;'>Email not found. Please enter a valid email address.</p>";
         
        }
    }
}

        ?>
        <form action="forgot_password.php" method="post" class="email-form">
            <label style="margin-left: -250px;">Email</label>
            <br>
            <!-- <input type="email" name="email" placeholder="Email" onblur="validateEmail()" oninput="validateEmail()" required > -->
            <?php
// Retrieve email parameter from URL
$email = isset($_GET['email']) ? urldecode($_GET['email']) : '';
?>

<!-- Modify your email input field to populate the email -->
<input type="email" name="email" id="email" value="<?php echo $email; ?>" placeholder="Enter your email" onblur="validateEmail()" oninput="validateEmail()" required >
            <p id="emailErrorMessage" style="color: red;"></p>
            <button type="submit" style="background-color: rgba(128, 0, 128, 0.7); color: white;">Continue</button>

        </form>
        <p>Remember your password? <a href="index.php">Login</a></p>
    </div>
</body>


</html>