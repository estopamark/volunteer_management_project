<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['login_attempts'])) {
    $_SESSION['login_attempts'] = 0;
}

// Maximum number of login attempts for volunteers and managers
$max_attempts = 3;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query to check if the username exists in the volunteers table
    $volunteer_query = "SELECT * FROM volunteers WHERE username='$username'";
    $volunteer_result = mysqli_query($conn, $volunteer_query);

    // Query to check if the username exists in the managers table
    $manager_query = "SELECT * FROM manager WHERE username='$username'";
    $manager_result = mysqli_query($conn, $manager_query);

    // Query to check if the username exists in the admin table
    $admin_query = "SELECT * FROM admin WHERE username='$username'";
    $admin_result = mysqli_query($conn, $admin_query);

    if (mysqli_num_rows($volunteer_result) > 0) {
        $row = mysqli_fetch_assoc($volunteer_result);
        // Verify the password for volunteer
        if (password_verify($password, $row['password'])) {
            $_SESSION['username'] = $username;
            $_SESSION['login_attempts'] = 0;
            header("Location: pages/dashboard_v.php");
            exit();
        }
    } elseif (mysqli_num_rows($manager_result) > 0) {
        $row = mysqli_fetch_assoc($manager_result);
        // Verify the password for manager
        if (password_verify($password, $row['password'])) {
            $_SESSION['username'] = $username;
            $_SESSION['login_attempts'] = 0;
            header("Location: pages/dashboard_m.php");
            exit();
        }
    } elseif (mysqli_num_rows($admin_result) > 0) {
        $row = mysqli_fetch_assoc($admin_result);
        // Verify the password for admin (assuming the password is not encrypted)
        if ($password === $row['password']) {
            $_SESSION['username'] = $username;
            $_SESSION['login_attempts'] = 0;
            header("Location: pages/dashboard_a.php");
            exit();
        }
    }

    // Increment login attempts for volunteers and managers
    $_SESSION['login_attempts']++;

    // Redirect to forgot password page if login attempts exceed the limit for volunteers and managers
    if ($_SESSION['login_attempts'] < $max_attempts) {
        header("Location: index.php?error=Invalid%20username%20or%20password");
        exit();
    }
    
    // Reset login attempts and redirect to forgot password page if max attempts reached
    $_SESSION['login_attempts'] = 3;
    header("Location: forgot_password.php");
    exit();
}
?>


