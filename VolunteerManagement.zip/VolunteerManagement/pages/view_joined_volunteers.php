<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Include database connection file
include_once "../includes/db.php";

// Check if eventId is provided in the URL
if (isset($_GET['eventId'])) {
    $eventId = $_GET['eventId'];
    
    // Query to fetch event details
    $eventQuery = "SELECT event_name FROM event WHERE event_id = '$eventId'";
    $eventResult = mysqli_query($conn, $eventQuery);
    
    if ($eventResult && mysqli_num_rows($eventResult) > 0) {
        $eventRow = mysqli_fetch_assoc($eventResult);
        $eventName = $eventRow['event_name'];
        
        // Query to fetch volunteers who joined the event
        $query = "SELECT volunteers FROM event WHERE event_id = '$eventId'";
        $result = mysqli_query($conn, $query);
        
        if ($result && mysqli_num_rows($result) > 0) {
            // Get the list of volunteers
            $row = mysqli_fetch_assoc($result);
            $volunteers = $row['volunteers'];
            
            if (!empty(trim($volunteers))) { // Check if the volunteers attribute is not empty or only contains spaces
                // Display the event name
                echo "<h2>Volunteer/s joined the $eventName</h2>";
                
                // Display the list of volunteers
                $volunteersList = explode(",", $volunteers);
                echo "<ul>";    
                foreach ($volunteersList as $volunteer) {
                    // Split the volunteer details by new lines and display each line as a list item
                    $volunteerLines = explode("\n", $volunteer);
                    foreach ($volunteerLines as $line) {
                        if (!empty(trim($line))) { // Check if the volunteer line is not empty or only contains spaces
                            echo "<li>$line</li>";
                        }
                    }
                }
                echo "</ul>";
            } else {
                echo "No volunteers have joined this event.";
            }
        } else {
            echo "<h2>Volunteers Joined the Event: $eventName</h2>";
            echo "No volunteers have joined this event.";
        }
    } else {
        echo "Error: Event not found.";
    }
} else {
    echo "Error: Event ID not provided.";
}

mysqli_close($conn);
?>
