<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include_once "../includes/db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $eventId = $_POST['eventId'];
    $volunteerName = $_SESSION['username'];

    // Delete the task entry associated with the volunteer and event
    $deleteTaskSql = "DELETE FROM task WHERE volunteer_name='$volunteerName' AND event_id=$eventId";
    if ($conn->query($deleteTaskSql) === TRUE) {
        echo "Withdrawal successful";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
