<?php
// Include database connection file
include_once "../includes/db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get event ID from POST data
    $eventId = $_POST["event_id"];

    // Retrieve event details from event table
    $stmt = $conn->prepare("SELECT * FROM event WHERE event_id = ?");
    $stmt->bind_param("i", $eventId);
    $stmt->execute();
    $result = $stmt->get_result();
    $eventData = $result->fetch_assoc();

    // Insert deleted event details into delete_event table
    $stmt = $conn->prepare("INSERT INTO delete_event (manager_fullname, event_name, deleted_at) VALUES (?, ?, NOW())");
    $stmt->bind_param("ss", $eventData['manager_fullname'], $eventData['event_name']);
    $stmt->execute();

    // Close statement and database connection
    $stmt->close();
    $conn->close();
}
?>
