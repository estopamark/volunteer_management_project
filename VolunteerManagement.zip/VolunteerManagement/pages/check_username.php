<?php
include __DIR__ . '/../includes/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["username"], $_POST["user_type"])) {
    $username = $conn->real_escape_string($_POST["username"]);
    $user_type = $conn->real_escape_string($_POST["user_type"]);

    // Choose the table based on the user type
    $table_name = ($user_type === 'manager') ? 'manager' : 'volunteers';

    // Check if username already exists
    $check_username_query = "SELECT * FROM $table_name WHERE username='$username'";
    $check_username_result = $conn->query($check_username_query);

    if ($check_username_result->num_rows > 0) {
        echo "taken";
    } else {
        echo "available";
    }
}
?>
