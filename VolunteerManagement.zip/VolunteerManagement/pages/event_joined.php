<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Include database connection file
include_once "../includes/db.php";

// Query to fetch events created by the manager
$managerUsername = $_SESSION['username'];
$sql = "SELECT * FROM event WHERE manager_username = '$managerUsername'";
$result = $conn->query($sql);
?>
<?php include_once "functions.php"; ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manager's Dashboard - Volunteer Management System</title>
    <link rel="stylesheet" href="../css/style2.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* Your CSS styles */
        /* Add or modify styles for the event feed */
        .event {
            border: 1px solid #ddd;
            margin-bottom: 20px;
            padding: 15px;
            background-color: #fff;
        }

        .event h3 {
            margin-top: 0;
        }

        .event p {
            margin-bottom: 10px;
        }

        .container {
            width: 100%;
            margin: 5px auto;
            display: flex;
            flex-direction: row; /* Arrange items horizontally */
        }

        .sidebar {
            flex: 1; /* Take 1/4 of the container */
            background-color: #008081; /* Updated background color */
            color: #05B8CC; /* Updated font color */
            padding: 0px;
            font-size: 18px; /* Adjust the font size for sidebar menu */
        }

        .menu {
            list-style-type: none;
            padding: 0px;
        }

        .menu a {
            display: block;
            text-decoration: none;
            color: #fff; /* Updated font color */
            padding: 30px;
            border-bottom: 1px solid #555;
            transition: background-color 0.3s ease;
        }

        .menu a:hover {
            background-color: #ffe5ec;
            color: #000;
        }

        .logout-link i {
            margin-right: 5px; /* Add a margin between icon and text */
        }

        .content {
            flex: 3; /* Take 3/4 of the container */
            padding: 20px;
            background-color: #fff;
        }

        .h2-username {
            color: #fff;
            text-align: center;
        }

        .h2-class {
            color: #000;
            text-align: center;
        }

        /* Additional styles for description */
        .event-description {
            margin-bottom: 10px;
        }

        .event-description ul {
            margin-top: 0;
            padding-left: 20px; /* Indent the bullet points */
        }

        .event-description li {
            margin-bottom: 5px;
        }

        /* Styles for event actions */
        .event-actions {
            margin-top: 10px;
            display: flex;
            justify-content: space-between;
        }

        .event-actions button {

            padding: 12px 230px; /* Updated padding to make buttons wider */
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            font-size: 14px;
        }

        .event-actions button i {
            margin-right: 5px;
        }

        .event-actions button.comment-btn {
            background-color: #1877f2; /* Facebook blue */
            color: #fff;
        }

        .event-actions button.joined-btn {
            background-color: #42b72a; /* Facebook green */
            color: #fff;
        }

        .event-actions button:hover {
            background-color: #ccc;
        }

        /* Styles for joined volunteers container */
        .floating-container {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
            z-index: 9999;
            width: 50%; /* Adjust the width as needed */
            max-height: 80%; /* Adjust the maximum height as needed */
            overflow-y: auto; /* Add scrollbar if content exceeds maximum height */
        }   

        .close-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            cursor: pointer;
            color: #777;
        }

        /* Styles to disable sidebar and event feed when floating container is open */
        .disable-sidebar, .disable-event-feed {
            pointer-events: none; /* Disable pointer events */
            opacity: 0.5; /* Reduce opacity to visually indicate that it's not clickable */
        }

        /* Additional styles for comments and replies */
        .comment-list {
            list-style-type: none;
            padding-left: 0;
        }

        .comment-list li {
            margin-bottom: 15px;
        }

        .reply-list {
            list-style-type: none;
            padding-left: 20px;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Volunteer Management System</h1>
    </header>

    <div class="container">
        <div class="sidebar <?php echo isset($floatingContainer) ? 'disable-sidebar' : ''; ?>">
            <h2 class="h2-username">Welcome, <?php echo isset($_SESSION['username']) ? $_SESSION['username'] : "Guest"; ?>!</h2>
            <ul class="menu">
                <li><a href="dashboard_m.php"><i class="fas fa-home"></i> Home</a></li>
                <li><a href=""><i class="fas fa-calendar"></i> My Events</a></li>
                <li><a href="#" onclick="loadCreateEventForm()"><i class="fas fa-calendar-plus"></i> Create Event</a></li>
                <li><a href="#" onclick="loadManagerNotifications()"><i class="fas fa-bell"></i> Notification</a></li>
                <li><a href="#" onclick="loadManagerProfile()"><i class="fas fa-user"></i> Profile</a></li>
                <li class="logout-link"><a href="../index.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>
        <div class="content <?php echo isset($floatingContainer) ? 'disable-event-feed' : ''; ?>" id="dashboardContent">
            <!-- Display Events Feed -->
            
            <?php
            if (isset($result) && $result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<div class='event'>";
                    echo "<h3> Event Name: " . $row["event_name"] . "</h3>"; // Display Event Name label inline with the event name
                    echo "<div class='event-description'><p><strong
                    >Description:</strong></p>"; // Display event description
                    // Split the description by new lines and display each line as a list item
                    $description_lines = explode("\n", $row["description"]);
                    echo "<ul>"; // Start unordered list
                    foreach($description_lines as $line) {
                        echo "<li>$line</li>"; // Display each line
                    }
                    echo "</ul></div>"; // End unordered list and event-description div
                    echo "<p><strong>Manager:</strong> " . $row["manager_fullname"] . "</p>"; // Display manager's full name
                    echo "<p><strong>Start Date:</strong> " . $row["start_date"] . "</p>";
                    echo "<p><strong>End Date:</strong> " . $row["end_date"] . "</p>";
                    echo "<p><strong>Start Time:</strong> " . $row["start_time"] . "</p>";
                    echo "<p><strong>End Time:</strong> " . $row["end_time"] . "</p>";
                    echo "<p><strong>Volunteers Needed:</strong> " . $row["no_of_volunteers"] . "</p>";
                    // Add the Comment and Joined buttons with icons
                    echo "<div class='event-actions'>";
                    echo "<button class='comment-btn' onclick='viewComments(\"".$row["event_id"]."\")'><i class='far fa-comment'></i> Comment</button>";
                    echo "<button class='joined-btn' onclick='viewJoinedVolunteers(\"".$row["event_id"]."\")'><i class='fas fa-user-friends'></i> Joined</button>";
                    echo "</div>"; // Close event-actions div
                    echo "</div>";
                }
            } else {
                echo "<p>No events added yet.</p>";
            }
            ?>
        </div>
    </div>

    <footer>
        <p>Volunteer Management System</p>
        <p>This project is developed by Mark Anthony Estopa</p>
    </footer>

    <!-- Your JavaScript code -->
    <script>
    // Function to load Create Event form
    function loadCreateEventForm() {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("dashboardContent").innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", "create_event_manager.php", true);
        xhttp.send();
    }

    // Function to load Manager Profile
    function loadManagerProfile() {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("dashboardContent").innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", "manager_profile.php", true);
        xhttp.send();
    }

    // Function to load Manager Notifications
    function loadManagerNotifications() {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {   
                document.getElementById("dashboardContent").innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", "notifications_m.php", true);
        xhttp.send();
    }

    // Function to view joined volunteers
    function viewJoinedVolunteers(eventId) {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                // Display the response in a floating container
                var joinedContainer = document.createElement("div");
                joinedContainer.className = "floating-container";
                joinedContainer.innerHTML = this.responseText;
                document.body.appendChild(joinedContainer);
                // Add close button functionality
                var closeButton = document.createElement("span");
                closeButton.className = "close-btn";
                closeButton.innerHTML = "&times;";
                closeButton.onclick = function() {
                    document.body.removeChild(joinedContainer);
                    document.querySelector('.content').classList.remove('disable-event-feed');
                    document.querySelector('.sidebar').classList.remove('disable-sidebar');
                };
                joinedContainer.appendChild(closeButton);
                // Disable event feed and sidebar
                document.querySelector('.content').classList.add('disable-event-feed');
                document.querySelector('.sidebar').classList.add('disable-sidebar');
            }
        };
        xhttp.open("GET", "view_joined_volunteers.php?eventId=" + eventId, true);
        xhttp.send();
    }

    // Function to close comment container
    function closeCommentContainer() {
        var commentContainer = document.querySelector('.floating-container');
        if (commentContainer) {
            document.body.removeChild(commentContainer);
            document.querySelector('.content').classList.remove('disable-event-feed');
            document.querySelector('.sidebar').classList.remove('disable-sidebar');
        }
    }

    // Function to post a comment
    function postComment() {
        var eventId = document.getElementById("eventId").value;
        var comment = document.getElementById("commentInput").value.trim();
        if (comment === "") {
            alert("Please enter a comment.");
            return;
        }

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                // Reload comments section after posting comment
                viewComments(eventId);
                // Close comment container
                closeCommentContainer();
            }
        };
        xhttp.open("POST", "post_comment.php", true);
        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhttp.send("eventId=" + encodeURIComponent(eventId) + "&comment=" + encodeURIComponent(comment));
    }

    // Function to view comments
    function viewComments(eventId) {
        // Close any existing comment containers
        closeCommentContainer();

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                // Display the response in a floating container
                var commentContainer = document.createElement("div");
                commentContainer.className = "floating-container";
                commentContainer.innerHTML = this.responseText;
                document.body.appendChild(commentContainer);
                
                // Add close button functionality
                var closeButton = document.createElement("span");
                closeButton.className = "close-btn";
                closeButton.innerHTML = "&times;";
                closeButton.onclick = closeCommentContainer;
                commentContainer.appendChild(closeButton);
                
                // Disable event feed and sidebar
                document.querySelector('.content').classList.add('disable-event-feed');
                document.querySelector('.sidebar').classList.add('disable-sidebar');
            }
        };
        xhttp.open("GET", "view_comments.php?eventId=" + eventId, true);
        xhttp.send();
    }
    // Function to post a reply
    function postReply(commentId) {
        var replyInput = document.querySelector('.reply-input[data-comment-id="' + commentId + '"]');
        var replyText = replyInput.value.trim();
        if (replyText === "") {
            alert("Please enter a reply.");
            return;
        }

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                // Reload comments section after posting reply
                viewComments(document.getElementById('eventId').value);
                // Clear reply input
                replyInput.value = "";
            }
        };
        xhttp.open("POST", "post_reply.php", true);
        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhttp.send("commentId=" + encodeURIComponent(commentId) + "&reply=" + encodeURIComponent(replyText));
    }
    </script>   
</body>
</html>

