<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include_once "../includes/db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['volunteerId'])) {
    $volunteerId = $_POST['volunteerId'];
    
    // SQL to delete volunteer
    $sql = "DELETE FROM volunteers WHERE id = $volunteerId";

    if ($conn->query($sql) === TRUE) {
        echo "Volunteer deleted successfully";
    } else {
        echo "Error deleting volunteer: " . $conn->error;
    }

    $conn->close();
} else {
    echo "Invalid request";
}
?>
