<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include database connection file
    include_once "../includes/db.php";

    // Get form data
    $eventName = $_POST["event_name"];
    $eventDescription = $_POST["event_description"]; // New line for event description
    $startDate = $_POST["start_date"];
    $endDate = $_POST["end_date"];
    $startTime = $_POST["start_time"];
    $endTime = $_POST["end_time"];
    $volunteers = $_POST["volunteers"];

    // Retrieve manager's full name and username from the session
    $managerUsername = $_SESSION['username'];
    $stmt = $conn->prepare("SELECT fullname FROM manager WHERE username = ?");
    $stmt->bind_param("s", $managerUsername);
    $stmt->execute();
    $result = $stmt->get_result();
    $managerData = $result->fetch_assoc();
    $managerFullName = $managerData['fullname'];

    // Prepare and execute SQL query to insert event into database including manager's full name and username
    $stmt = $conn->prepare("INSERT INTO event (event_name, description, start_date, end_date, start_time, end_time, no_of_volunteers, manager_fullname, manager_username, datetime) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("sssssssss", $eventName, $eventDescription, $startDate, $endDate, $startTime, $endTime, $volunteers, $managerFullName, $managerUsername);
    $stmt->execute();

    // Get the last inserted event ID
    $eventId = $conn->insert_id;

    // Insert a notification for volunteers
    $stmt = $conn->prepare("INSERT INTO notifications_v (event_id, manager_fullname, event_name, created_at) VALUES (?, ?, ?, NOW())");
    $stmt->bind_param("iss", $eventId, $managerFullName, $eventName);
    $stmt->execute();

    // Close statement and database connection
    $stmt->close();
    $conn->close();

    // Redirect to dashboard after adding event
    header("Location: dashboard_m.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Event - Volunteer Management System</title>
    <link rel="stylesheet" href="../css/style.css"> <!-- Assuming you have a CSS file for styling -->
    <style>
        /* CSS for create_event_manager.php */

        /* General styles for form container */
        .container {
            width: 100%;
            height: 140vh;
            margin: 5px auto;
            display: flex;
            flex-direction: row;

        }

        /* Styles for form labels */
        label {
            display: block;
            margin-bottom: 5px;
            color: #333;
        }

        /* Styles for form inputs */
        input[type="text"],
        input[type="date"],
        input[type="time"],
        input[type="number"],
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        /* Styles for submit button */
        input[type="submit"] {
            background-color: #00ab41;
            color: #fff;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #6B6B6B;
        }

        /* Optional: Adjust font styles */
        body {
            font-family: Arial, sans-serif;
            font-size: 16px;
            line-height: 1.6;
            color: #333;
        }
        h2 {
            color: #051650;
            text-align: center;
        }
        .sidebar {
            flex: 1; /* Take 1/4 of the container */
            background-color: #008081; /* Updated background color */
            color: #05B8CC; /* Updated font color */
            padding: 0px;
            font-size: 18px; /* Adjust the font size for sidebar menu */
        }

        .menu {
            list-style-type: none;
            padding: 0px;
        }

        .menu a {
            display: block;
            text-decoration: none;
            color: #fff; /* Updated font color */
            padding: 30px;
            border-bottom: 1px solid #555;
            transition: background-color 0.3s ease;
        }

        .menu a:hover {
            background-color: #ffe5ec;
            color: #000;
        }
    </style>
</head>
<body>
<h2>Create Event</h2>
<div class="container">
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="event_name">Event Name</label>
        <input type="text" id="event_name" name="event_name" required><br><br>

        <label for="event_description">Description</label> <!-- New label for event description -->
        <textarea id="event_description" name="event_description" rows="6" cols="50"></textarea><br><br> <!-- New textarea for event description -->

        <label for="start_date">Start Date</label> <!-- Updated label -->
        <input type="date" id="start_date" name="start_date" required><br><br> <!-- Updated input id and name -->

        <label for="end_date">End Date</label> <!-- Updated label -->
        <input type="date" id="end_date" name="end_date" required><br><br> <!-- Updated input id and name -->

        <label for="start_time">Start Time</label>
        <input type="time" id="start_time" name="start_time" required><br><br>

        <label for="end_time">End Time</label>
        <input type="time" id="end_time" name="end_time" required><br><br>

        <label for="volunteers">Volunteers Needed</label>
        <input type="number" id="volunteers" name="volunteers" required><br><br>

        <input type="submit" value="Submit">
    </form>
</div>
</body>
</html>
