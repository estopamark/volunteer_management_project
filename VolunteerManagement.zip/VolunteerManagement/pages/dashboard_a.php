<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Include database connection file
include_once "../includes/db.php";

// Query to fetch events
$sql = "SELECT * FROM event";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin's Dashboard - Volunteer Management System</title>
    <link rel="stylesheet" href="../css/style2.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* Your CSS styles */
        /* Add or modify styles for the event feed */
        .event {
            position: relative; /* Ensure positioning for buttons */
            border: 1px solid #ddd;
            margin-bottom: 20px;
            padding: 15px;
            background-color: #fff;
        }

        .event h3 {
            margin-top: 0;
        }

        .event p {
            margin-bottom: 10px;
        }

        .event-buttons {
            position: absolute;
            top: 10px;
            right: 10px;
        }

        .edit-btn,
        .delete-btn {
            background-color: #0A6522; /* Green color for edit button */
            color: #fff;
            border: none;
            padding: 5px 10px; /* Adjusted padding */
            margin-right: 5px;
            cursor: pointer;
            border-radius: 5px;
        }

        .delete-btn {
            background-color: #ff6347; /* Red color for delete button */
        }

        .edit-btn:hover,
        .delete-btn:hover {
            opacity: 0.8; /* Reduce opacity on hover */
        }

        .container {
            width: 100%;
            margin: 5px auto;
            display: flex;
            flex-direction: row; /* Arrange items horizontally */
        }

        .sidebar {
            flex: 1; /* Take 1/4 of the container */
            background-color: #333;
            color: #fff;
            padding: 0px;
            font-size: 18px; /* Adjust the font size for sidebar menu */
        }

        .menu {
            list-style-type: none;
            padding: 0px;
        }

        .menu a {
            display: block;
            text-decoration: none;
            color: #fff;
            padding: 30px;
            border-bottom: 1px solid #555;
            transition: background-color 0.3s ease;
        }

        .menu a:hover {
            background-color: #ffe5ec;
            color: #000;
        }

        .logout-link i {
            margin-right: 5px; /* Add a margin between icon and text */
        }

        .content {
            flex: 3; /* Take 3/4 of the container */
            padding: 20px;
            background-color: #fff;
        }

        h2 {
            color: #FF7900;
            text-align: center;
        }
    </style>
</head>
<body>
    <header>
        <h1>Volunteer Management System</h1>
    </header>

    <div class="container">
        <div class="sidebar">
            <h2>Welcome, <?php echo isset($_SESSION['username']) ? $_SESSION['username'] : "Guest"; ?>!</h2>
            <ul class="menu">
                <li><a href="dashboard_a.php"><i class="fas fa-home"></i> Home</a></li>
                <li><a href="managers.php"><i class="fas fa-user-tie"></i> Managers</a></li>
                <li><a href="volunteers.php"><i class="fas fa-user-friends"></i> Volunteers</a></li>
                <li class="logout-link"><a href="../index.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>
        <div class="content" id="dashboardContent">
            <!-- Display Events Feed -->
            <h2>All Events</h2>
            <?php
            if (isset($result) && $result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<div class='event'>";
                    echo "<div class='event-buttons'>"; 
                    echo "<button class='edit-btn' onclick='editEvent(" . $row['event_id'] . ")'>Edit</button>";
                    echo "<button class='delete-btn' onclick='deleteEvent(" . $row['event_id'] . ")'>Delete</button>";
                    echo "</div>";
                    echo "<h1>" . $row["event_name"] . "</h1>";
                    echo "<p><strong>Manager:</strong> " . $row["manager_fullname"] . "</p>";
                    echo "<p><strong>Start Date:</strong> " . $row["start_date"] . "</p>";
                    echo "<p><strong>End Date:</strong> " . $row["end_date"] . "</p>";
                    echo "<p><strong>Start Time:</strong> " . $row["start_time"] . "</p>";
                    echo "<p><strong>End Time:</strong> " . $row["end_time"] . "</p>";
                    echo "<p><strong>Volunteers Needed:</strong> " . $row["no_of_volunteers"] . "</p>";
                    echo "</div>";
                }
            } else {
                echo "<p>No events added yet.</p>";
            }
            ?>
        </div>
    </div>

    <footer>    
        <p>Volunteer Management System</p>
        <p>This project is developed by Mark Anthony Estopa</p>
    </footer>

    <!-- Your JavaScript code -->
    <script>
    // Function to edit event
    function editEvent(eventId) {
        // Redirect to edit_event_a.php with eventId parameter
        window.location.href = "edit_event_a.php?event_id=" + eventId;
    }

    // Function to delete event
    function deleteEvent(eventId) {
        if (confirm("Are you sure you want to delete this event?")) {
            // Send AJAX request to delete event from database
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    // Reload page after successful deletion
                    window.location.reload();
                }
            };
            xhttp.open("GET", "delete_event_a.php?event_id=" + eventId, true);
            xhttp.send();
        }
    }
    </script>
</body>
</html>
