<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['event_id'])) {
    // Include database connection file
    include_once "../includes/db.php";

    // Get event ID
    $eventId = $_GET['event_id'];

    // Prepare and execute SQL query to delete event from the database
    $stmt = $conn->prepare("DELETE FROM event WHERE event_id = ?");
    $stmt->bind_param("i", $eventId);
    $stmt->execute();

    // Close statement and database connection
    $stmt->close();
    $conn->close();

    // Redirect back to dashboard after deleting event
    header("Location: dashboard_a.php");
    exit();
} else {
    // Invalid request
    header("Location: dashboard_a.php");
    exit();
}
?>
