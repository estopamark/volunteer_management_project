<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Include database connection file
include_once "../includes/db.php";

// Query to fetch events
$sql = "SELECT * FROM event";
$result = $conn->query($sql);
?>
<?php include_once "functions.php"; ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manager's Dashboard - Volunteer Management System</title>
    <link rel="stylesheet" href="../css/style2.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* Your CSS styles */
        /* Add or modify styles for the event feed */
        .event {
            position: relative; /* Ensure positioning for buttons */
            border: 1px solid #ddd;
            margin-bottom: 20px;
            padding: 15px;
            background-color: #fff;
        }

        .event h3 {
            margin-top: 0;
        }

        .event p {
            margin-bottom: 10px;
        }

        .event-buttons {
            position: absolute;
            top: 10px;
            right: 10px;
        }

        .edit-btn,
        .delete-btn {
            background-color: #0A6522; /* Green color for edit button */
            color: #fff;
            border: none;
            padding: 5px 10px; /* Adjusted padding */
            margin-right: 5px;
            cursor: pointer;
            border-radius: 5px;
        }

        .delete-btn {
            background-color: #ff6347; /* Red color for delete button */
        }

        .edit-btn:hover,
        .delete-btn:hover {
            opacity: 0.8; /* Reduce opacity on hover */
        }

        .container {
            width: 100%;
            margin: 5px auto;
            display: flex;
            flex-direction: row; /* Arrange items horizontally */
        }

        .sidebar {
            flex: 1; /* Take 1/4 of the container */
            background-color: #008081; /* Updated background color */
            color: #05B8CC; /* Updated font color */
            padding: 0px;
            font-size: 18px; /* Adjust the font size for sidebar menu */
        }

        .menu {
            list-style-type: none;
            padding: 0px;
        }

        .menu a {
            display: block;
            text-decoration: none;
            color: #fff; /* Updated font color */
            padding: 30px;
            border-bottom: 1px solid #555;
            transition: background-color 0.3s ease;
        }

        .menu a:hover {
            background-color: #ffe5ec;
            color: #000;
        }

        .logout-link i {
            margin-right: 5px; /* Add a margin between icon and text */
        }

        .content {
            flex: 3; /* Take 3/4 of the container */
            padding: 20px;
            background-color: #fff;
        }

        .h2-username {
            color: #fff;
            text-align: center;
        }

        .h2-class {
            color: #000;
            text-align: center;
        }

        /* Additional styles for description */
        .event-description {
            margin-bottom: 10px;
        }

        .event-description ul {
            margin-top: 0;
            padding-left: 20px; /* Indent the bullet points */
        }

        .event-description li {
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Volunteer Management System</h1>
    </header>

    <div class="container">
        <div class="sidebar">
            <h2 class="h2-username">Welcome, <?php echo isset($_SESSION['username']) ? $_SESSION['username'] : "Guest"; ?>!</h2>
            <ul class="menu">
                <li><a href="dashboard_m.php"><i class="fas fa-home"></i> Home</a></li>
                <li><a href="event_joined.php"><i class="fas fa-calendar"></i> My Events</a></li>
                <li><a href="#" onclick="loadCreateEventForm()"><i class="fas fa-calendar-plus"></i> Create Event</a></li>
                <li><a href="#" onclick="loadManagerNotifications()"><i class="fas fa-bell"></i> Notification</a></li>
                <li><a href="#" onclick="loadManagerProfile()"><i class="fas fa-user"></i> Profile</a></li>
                <li class="logout-link"><a href="../index.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>
        <div class="content" id="dashboardContent">
            <!-- Display Events Feed -->
            <h2 class="h2-class">All Events</h2>
            <?php
            if (isset($result) && $result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<div class='event'>";
                    echo "<div class='event-buttons'>"; 
                    // Check if the logged-in manager created this event
                    if ($row['manager_username'] === $_SESSION['username']) {
                        // If yes, allow edit and delete
                        echo "<button class='edit-btn' onclick='editEvent(" . $row['event_id'] . ")'>Edit</button>";
                        echo "<button class='delete-btn' onclick='deleteEvent(" . $row['event_id'] . ")'>Delete</button>";
                    } else {
                        // If not, show disabled buttons and alert message
                        echo "<button class='edit-btn' onclick='alertPermission()'>Edit</button>";
                        echo "<button class='delete-btn' onclick='alertPermission()'>Delete</button>";
                    }
                    echo "</div>";

                    echo "<h3> Event Name: " . $row["event_name"] . "</h3>"; // Display Event Name label inline with the event name
                    echo "<div class='event-description'><p><strong>Description:</strong></p>"; // Display event description
                    // Split the description by new lines and display each line as a list item
                    $description_lines = explode("\n", $row["description"]);
                    echo "<ul>"; // Start unordered list
                    foreach($description_lines as $line) {
                        echo "<li>$line</li>"; // Display each line as a list item
                    }
                    echo "</ul></div>"; // End unordered list and event-description div
                    echo "<p><strong>Manager:</strong> " . $row["manager_fullname"] . "</p>"; // Display manager's full name
                    echo "<p><strong>Start Date:</strong> " . $row["start_date"] . "</p>";
                    echo "<p><strong>End Date:</strong> " . $row["end_date"] . "</p>";
                    echo "<p><strong>Start Time:</strong> " . $row["start_time"] . "</p>";
                    echo "<p><strong>End Time:</strong> " . $row["end_time"] . "</p>";
                    echo "<p><strong>Volunteers Needed:</strong> " . $row["no_of_volunteers"] . "</p>";
                    echo "</div>";
                }
            } else {
                echo "<p>No events added yet.</p>";
            }
            ?>
        </div>
    </div>

    <footer>
        <p>Volunteer Management System</p>
        <p>This project is developed by Mark Anthony Estopa</p>
    </footer>

    <!-- Your JavaScript code -->
    <script>
    // Function to load Create Event form
    function loadCreateEventForm() {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("dashboardContent").innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", "create_event_manager.php", true);
        xhttp.send();
    }

    // Function to load Manager Profile
    function loadManagerProfile() {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("dashboardContent").innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", "manager_profile.php", true);
        xhttp.send();
    }

    // Function to edit event
    function editEvent(eventId) {
        // Redirect to edit_event.php with eventId parameter
        window.location.href = "edit_event.php?event_id=" + eventId;
    }

    // Function to delete event
    function deleteEvent(eventId) {
        if (confirm("Are you sure you want to delete this event?")) {
            // Send AJAX request to delete event from database
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    // Reload page after successful deletion
                    window.location.reload();
                }
            };
            xhttp.open("POST", "delete_event.php", true);
            xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhttp.send("event_id=" + eventId);
        }
    }

    // Function to alert user of permission denial
    function alertPermission() {
        alert("You don't have permission to perform this action!");
    }
    // Function to load Manager Notifications
    function loadManagerNotifications() {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {   
                document.getElementById("dashboardContent").innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", "notifications_m.php", true);
        xhttp.send();
    }

    // Inside deleteEvent function
function deleteEvent(eventId) {
    if (confirm("Are you sure you want to delete this event?")) {
        // Send AJAX request to delete event from database
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                // Reload page after successful deletion
                window.location.reload();
            }
        };
        xhttp.open("POST", "delete_event.php", true);
        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhttp.send("event_id=" + eventId);

        // Add code to notify volunteers about event deletion
        var notificationData = {
            event_id: eventId
        };
        // Send AJAX request to notify volunteers
        var notifyVolunteersRequest = new XMLHttpRequest();
        notifyVolunteersRequest.open("POST", "notify_volunteers.php", true);
        notifyVolunteersRequest.setRequestHeader("Content-Type", "application/json");
        notifyVolunteersRequest.send(JSON.stringify(notificationData));
    }
}


    </script>   
</body>
</html>
