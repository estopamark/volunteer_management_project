<?php
// Start the session to access session variables
session_start();

// Include the file that establishes the database connection
include_once "../includes/db.php";

// Check if the manager is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Make sure $conn is defined and not null
if(isset($conn)) {
    // Fetch notifications for the manager based on events joined or withdrawn by volunteers
    $managerUsername = $_SESSION['username'];
    $sql = "SELECT 'joined' AS type, t.task_id, t.event_id, t.volunteer_username, t.joined_at AS event_time, e.event_name, v.fullname AS volunteer_fullname
        FROM task t 
        JOIN event e ON t.event_id = e.event_id 
        JOIN volunteers v ON t.volunteer_username = v.username
        WHERE e.manager_username = '$managerUsername'
        UNION
        SELECT 'withdrawn' AS type, NULL AS task_id, w.event_id, w.volunteer_username, w.withdrew_at AS event_time, e.event_name, v.fullname AS volunteer_fullname
        FROM withdraw_task w 
        JOIN event e ON w.event_id = e.event_id 
        JOIN volunteers v ON w.volunteer_username = v.username
        WHERE e.manager_username = '$managerUsername'
        ORDER BY event_time DESC"; // Ordering by event_time DESC to display recent events at the top

    $result = $conn->query($sql);

    // Display notifications
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Determine notification type and format notification information accordingly
            $notificationType = $row['type'];
            $volunteerFullName = "<strong>{$row['volunteer_fullname']}</strong>";
            $eventName = "<strong>'{$row['event_name']}'</strong>";
            $eventTime = date("F j, Y, g:i a", strtotime($row['event_time']));

            // Start notification container
            echo "<div style='border: 5px solid #ddd; padding: 10px; margin-bottom: 10px; border-radius: 10px;'>";
            
            // Display notification information
            if ($notificationType === 'joined') {
                $notificationInfo = "$volunteerFullName joined your event '$eventName'.";
                echo "<p>$notificationInfo</p>";
            } else {
                $notificationInfo = "$volunteerFullName withdrew from your event '$eventName'.";
                echo "<p>$notificationInfo</p>";
            }

            // Display event time
            echo "<p>$eventTime</p>";

            // End notification container
            echo "</div>";
        }
    } else {
        echo "<p>No notifications.</p>";
    }
} else {
    echo "<p>Database connection error.</p>";
}
?>
