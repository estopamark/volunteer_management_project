<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include database connection file
    include_once "../includes/db.php";

    // Retrieve data from POST request
    $commentId = mysqli_real_escape_string($conn, $_POST['commentId']);
    $reply = mysqli_real_escape_string($conn, $_POST['reply']);
    $username = $_SESSION['username'];

    // Insert reply into database
    $sql = "INSERT INTO replies (comment_id, username, reply_text, created_at) VALUES ('$commentId', '$username', '$reply', NOW())";

    if (mysqli_query($conn, $sql)) {
        echo "Reply posted successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    mysqli_close($conn);
    exit();
} else {
    echo "Invalid request method.";
}
?>
