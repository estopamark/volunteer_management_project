<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include_once "../includes/db.php";

function getManagers($conn) {
    $sql = "SELECT * FROM manager";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        echo "<table>";
        echo "<tr><th>Name</th><th>Email</th><th>Contact No</th><th>Actions</th></tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["fullname"] . "</td>";
            echo "<td>" . $row["email"] . "</td>";
            echo "<td>" . $row["contact_no"] . "</td>";
            echo "<td>";
            echo "<button class='edit-btn' onclick='editManager(" . $row['id'] . ")'>Edit</button>";
            echo "<button class='delete-btn' onclick='deleteManager(" . $row['id'] . ")'>Delete</button>";
            echo "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No managers added yet.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manager Dashboard - Volunteer Management System</title>
    <link rel="stylesheet" href="../css/style2.css"> <!-- Assuming you have a CSS file for styling -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> <!-- Link to Font Awesome for icons -->
    <style>
        /* Your existing CSS styles */
        /* Add or modify styles for the managers table */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        .edit-btn {
            background-color: #006400; /* Dark green color for edit button */
            color: #fff;
            border: none;
            padding: 5px 10px;
            margin-right: 5px;
            cursor: pointer;
            border-radius: 3px;
        }

        .delete-btn {
            background-color: #FF0000; /* Red color for delete button */
            color: #fff;
            border: none;
            padding: 5px 10px;
            margin-right: 5px;
            cursor: pointer;
            border-radius: 3px;
        }

        button:hover {
            opacity: 0.8;
        }
        .container {
        width: 100%;
        margin: 5px auto;
        display: flex;
        flex-direction: row; /* Arrange items horizontally */
    }

    .sidebar {
        flex: 1; /* Take 1/4 of the container */
        background-color: #333;
        color: #fff;
        padding: 0px;
        font-size: 18px; /* Adjust the font size for sidebar menu */
    }

    .menu {
        list-style-type: none;
        padding: 0px;
    }

    .menu a {
        display: block;
        text-decoration: none;
        color: #fff;
        padding: 30px;
        border-bottom: 1px solid #555;
        transition: background-color 0.3s ease;
    }

    .menu a:hover {
        background-color: #ffe5ec;
        color: #000;
    }

    .logout-link i {
        margin-right: 5px; /* Add a margin between icon and text */
    }

    .content {
        flex: 3; /* Take 3/4 of the container */
        padding: 20px;
        background-color: #fff;
    }
     h2 {
        color: #FF7900;
        text-align: center;
    }

    </style>
</head>
<body>
    <header>
        <h1>Volunteer Management System</h1>
    </header>

    <div class="container">
        <div class="sidebar">
            <h2>Welcome, <?php echo isset($_SESSION['username']) ? $_SESSION['username'] : "Guest"; ?>!</h2>
            <ul class="menu">
                <li><a href="dashboard_a.php" onclick="loadDashboardContent()"><i class="fas fa-home"></i> Home</a></li> <!-- Add an icon to the Home menu -->
                <li><a href="managers.php"><i class="fas fa-user-tie"></i> Managers</a></li> <!-- Link to the Managers page -->
                <li><a href="volunteers.php"><i class="fas fa-user-friends"></i> Volunteers</a></li>
                <li class="logout-link"><a href="../index.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li> <!-- Add an icon to the Logout menu -->
            </ul>
        </div>
        <div class="content">
            <h2>All Managers</h2>
            <?php
                getManagers($conn);
            ?>
        </div>
    </div>

    <footer>    
        <p>Volunteer Management System</p>
        <p>This project is developed by Mark Anthony Estopa</p>
    </footer>
    <script>
    function editManager(managerId) {
        window.location.href = "edit_managers.php?managerId=" + managerId;
    }

    function deleteManager(managerId) {
        if (confirm("Are you sure you want to delete this manager?")) {
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    window.location.reload();
                }
            };
            xhttp.open("POST", "delete_managers.php", true);
            xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhttp.send("managerId=" + managerId);
        }
    }
</script>

</body>
</html>
