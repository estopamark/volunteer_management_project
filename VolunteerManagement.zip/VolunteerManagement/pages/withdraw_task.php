<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include_once "../includes/db.php";

if (isset($_POST['taskId'])) {
    $taskId = mysqli_real_escape_string($conn, $_POST['taskId']);
    $volunteerUsername = $_SESSION['username'];
    
    // Retrieve volunteer fullname from the volunteers table based on username
    $volunteerFullnameQuery = "SELECT fullname FROM volunteers WHERE username = '$volunteerUsername'";
    $volunteerFullnameResult = mysqli_query($conn, $volunteerFullnameQuery);
    
    if ($volunteerFullnameResult && mysqli_num_rows($volunteerFullnameResult) > 0) {
        $row = mysqli_fetch_assoc($volunteerFullnameResult);
        $volunteerFullname = $row['fullname'];
    } else {
        $volunteerFullname = ""; // Set empty string if fullname not found
    }

    // Fetch the event ID associated with the task
    $eventQuery = "SELECT event_id FROM task WHERE task_id = '$taskId'";
    $eventResult = mysqli_query($conn, $eventQuery);
    if ($eventResult && mysqli_num_rows($eventResult) > 0) {
        $eventRow = mysqli_fetch_assoc($eventResult);
        $eventId = $eventRow['event_id'];

        // Begin a transaction
        mysqli_begin_transaction($conn);

        // Delete the task record
        $deleteQuery = "DELETE FROM task WHERE task_id = '$taskId'";
        if (mysqli_query($conn, $deleteQuery)) {
            // Remove the volunteer's fullname from the event's volunteers attribute
            $updateEventQuery = "UPDATE event SET volunteers = REPLACE(volunteers, '$volunteerFullname\n', '') WHERE event_id = '$eventId'";
            if (mysqli_query($conn, $updateEventQuery)) {
                // Update the number of volunteers needed for the event
                $updateNoOfVolunteersQuery = "UPDATE event SET no_of_volunteers = no_of_volunteers + 1 WHERE event_id = '$eventId'";
                if (mysqli_query($conn, $updateNoOfVolunteersQuery)) {
                    // Get current time in the Philippines
                    date_default_timezone_set('Asia/Manila');
                    $withdrawAt = date("Y-m-d H:i:s");
                    // Insert withdrawal data into withdraw_task table
                    $insertWithdrawQuery = "INSERT INTO withdraw_task (volunteer_username, volunteer_fullname, event_id, withdrew_at) VALUES ('$volunteerUsername', '$volunteerFullname', '$eventId', '$withdrawAt')";
                    if (mysqli_query($conn, $insertWithdrawQuery)) {
                        // If all updates are successful, commit the transaction
                        mysqli_commit($conn);
                        echo "Task withdrawn successfully!";
                    } else {
                        // If insertion fails, rollback the transaction
                        mysqli_rollback($conn);
                        echo "Error: " . mysqli_error($conn);
                    }
                } else {
                    // If update fails, rollback the transaction
                    mysqli_rollback($conn);
                    echo "Error: " . mysqli_error($conn);
                }
            } else {
                // If update fails, rollback the transaction
                mysqli_rollback($conn);
                echo "Error: " . mysqli_error($conn);
            }
        } else {
            // If deletion fails, rollback the transaction
            mysqli_rollback($conn);
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        echo "Error: Task not found.";
    }
} else {
    echo "Error: taskId is required.";
}

mysqli_close($conn);
?>
