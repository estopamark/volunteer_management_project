<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Volunteer Dashboard</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            background-image: url(background.jpg);
            background-size: cover;
            background-repeat: no-repeat;
            margin: 0;
            padding: 0;
        }
        header {
            color: #fff;
            padding: 20px;
            text-align: center;
            background-color: rgba(128, 0, 128, 0.8); /* Adjusted opacity */
            padding: 10px;
            text-align: center;
            font-size: 20px;
            box-shadow: 5px 12px 24px rgba(0, 0, 0, 0.5); /* Updated box shadow */
        }
        
        }
    </style>
</head>
<body>
    <header>
        <h1>Volunteer Management System</h1>
        <nav>
            <!-- Add navigation links here -->
        </nav>
    </header>
    
