<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include database connection file
    include_once "../includes/db.php";

    // Retrieve data from POST request
    $eventId = mysqli_real_escape_string($conn, $_POST['eventId']);
    $comment = mysqli_real_escape_string($conn, $_POST['comment']);
    $username = $_SESSION['username'];

    // Insert comment into database
    $sql = "INSERT INTO comments (event_id, username, comment_text, created_at) VALUES ('$eventId', '$username', '$comment', NOW())";
    if (mysqli_query($conn, $sql)) {
        echo "Comment posted successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    mysqli_close($conn);
    exit();
} else {
    echo "Invalid request method.";
}
?>
