<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include_once "../includes/db.php";

$username = $_SESSION['username'];
$sql = "SELECT t.task_id, t.total_hours, e.event_id, e.event_name, e.manager_fullname, e.start_date, e.end_date, e.start_time, e.end_time, e.description FROM event e JOIN task t ON e.event_id = t.event_id WHERE t.volunteer_username='$username'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Tasks - Volunteer Management System</title>
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <style>
        /* CSS for my_tasks.php */
        /* Styles for sidebar */
        .sidebar {
            flex: 1;
            background-color: #FFD800;
            color: #000;
            padding: 0px;
            font-size: 18px;
        }

        .menu {
            list-style-type: none;
            padding: 0px;
        }

        .menu a {
            display: block;
            text-decoration: none;
            color: #000;
            padding: 30px;
            border-bottom: 1px solid #555;
            transition: background-color 0.3s ease;
        }

        .menu a:hover {
            background-color: #363636;
            color: #fff;
        }

        /* General styles for tasks container */
        .tasks-container {
            width: 90%;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f9f9f9;
        }

        /* Styles for task items */
        .task-item {
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #fff;
            position: relative;
        }

        /* Styles for total hours label */
        .total-hours-label {
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        /* Styles for task details */
        .task-details {
            margin-bottom: 10px;
        }

        /* Optional: Adjust font styles */
        body {
            font-family: Arial, sans-serif;
            font-size: 16px;
            line-height: 1.6;
            color: #333;
        }
        h2 {
            color: #000;
            text-align: center;
        }

        /* Styles for withdraw button */
        .withdraw-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: red;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 3px;
            cursor: pointer;
        }

        .withdraw-btn i {
            margin-right: 5px;
        }

        /* Styles for comment button */
        .comment-btn {
            background-color: #1877f2;
            color: #fff;
            border: none;
            padding: 10px 30px;
            border-radius: 5px;
            cursor: pointer;
            position: ;
            bottom: 10px;
            left: 10px;
        }

        .comment-btn i {
            margin-right: 5px;
        }

        .comment-btn:hover {
            opacity: 0.8;
        }

        /* Styles for event description */
        .event-description ul {
            margin-top: 0;
            padding-left: 20px;
        }

        .event-description li {
            margin-bottom: 5px;
        }
        /* Styles for comment button */
        .comment-btn {
            background-color: #1877f2;
            color: #fff;
            border: none;
            padding: 10px 40px;
            border-radius: 5px;
            cursor: pointer;
            position: ;
            bottom: 10px; /* Adjusted position */
            left: 10px;
        }

        
        .floating-container {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
            z-index: 9999;
            width: 50%; /* Adjust the width as needed */
            max-height: 80%; /* Adjust the maximum height as needed */
            overflow-y: auto; /* Add scrollbar if content exceeds maximum height */
        }   

        .close-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            cursor: pointer;
            color: #777;
        }

        /* Styles to disable sidebar and event feed when floating container is open */
        .disable-sidebar, .disable-event-feed {
            pointer-events: none; /* Disable pointer events */
            opacity: 0.5; /* Reduce opacity to visually indicate that it's not clickable */
        }

        /* Additional styles for comments and replies */
        .comment-list {
            list-style-type: none;
            padding-left: 0;
        }

        .comment-list li {
            margin-bottom: 15px;
        }

        .reply-list {
            list-style-type: none;
            padding-left: 20px;
            margin-top: 10px;
        }
    </style>
</head>
<body>

<h2>My Tasks</h2>
<div class="tasks-container">
    <?php
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<div class='task-item'>";
            echo "<div class='task-details'>";
            // Display total hours label
            echo "<div class='total-hours-label'>Total Hours: " . $row['total_hours'] . "</div>";
            echo "<h3>Event Name: " . $row['event_name'] . "</h3>";
            echo "<div class='event-description'>";
            echo "<p><strong>Description:</strong></p>";
            echo "<ul>";
            // Split the description by new lines and display each line as a list item
            $description_lines = explode("\n", $row["description"]);
            foreach ($description_lines as $line) {
                echo "<li>$line</li>";
            }
            echo "</ul>";
            echo "</div>"; // Close event-description
            echo "<p><strong>Manager:</strong> " . $row['manager_fullname'] . "</p>";
            echo "<p><strong>Start Date:</strong> " . $row['start_date'] . "</p>";
            echo "<p><strong>End Date:</strong> " . $row['end_date'] . "</p>";
            echo "<p><strong>Start Time:</strong> " . $row['start_time'] . "</p>";
            echo "<p><strong>End Time:</strong> " . $row['end_time'] . "</p>";
            echo "</div>"; // Close task-details
            // Add withdraw button with onclick event
            echo "<button class='withdraw-btn' onclick='withdrawTask(" . $row['task_id'] . ")'><i class='fas fa-sign-out-alt'></i> Withdraw</button>";
            // Add the Comment button with icons
            echo "<div class='event-actions'>";
            echo "<button class='comment-btn' onclick='viewComments(\"".$row["event_id"]."\")'><i class='far fa-comment'></i> Comment</button>";
            echo "</div>"; // Close event-actions div
            echo "</div>";
        }
    } else {
        echo "<p>No tasks joined yet.</p>";
    }
    ?>
</div>

<script>
    // Function to handle withdrawing from task
    function withdrawTask(taskId) {
        if (confirm("Do you really want to withdraw from this task?")) {
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    // Reload the page to reflect changes
                    window.location.reload();
                }
            };
            xhttp.open("POST", "withdraw_task.php", true);
            xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhttp.send("taskId=" + taskId);
        }
    }

    function closeCommentContainer() {
        var commentContainer = document.querySelector('.floating-container');
        if (commentContainer) {
            document.body.removeChild(commentContainer);
            document.querySelector('.content').classList.remove('disable-event-feed');
            document.querySelector('.sidebar').classList.remove('disable-sidebar');
        }
    }

    // Function to post a comment
    function postComment() {
        var eventId = document.getElementById("eventId").value;
        var comment = document.getElementById("commentInput").value.trim();
        if (comment === "") {
            alert("Please enter a comment.");
            return;
        }

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                // Reload comments section after posting comment
                viewComments(eventId);
                // Close comment container
                closeCommentContainer();
            }
        };
        xhttp.open("POST", "post_comment.php", true);
        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhttp.send("eventId=" + encodeURIComponent(eventId) + "&comment=" + encodeURIComponent(comment));
    }

    // Function to view comments
    function viewComments(eventId) {
        // Close any existing comment containers
        closeCommentContainer();

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                // Display the response in a floating container
                var commentContainer = document.createElement("div");
                commentContainer.className = "floating-container";
                commentContainer.innerHTML = this.responseText;
                document.body.appendChild(commentContainer);
                
                // Add close button functionality
                var closeButton = document.createElement("span");
                closeButton.className = "close-btn";
                closeButton.innerHTML = "&times;";
                closeButton.onclick = closeCommentContainer;
                commentContainer.appendChild(closeButton);
                
                // Disable event feed and sidebar
                document.querySelector('.content').classList.add('disable-event-feed');
                document.querySelector('.sidebar').classList.add('disable-sidebar');
            }
        };
        xhttp.open("GET", "view_comments.php?eventId=" + eventId, true);
        xhttp.send();
    }
    // Function to post a reply
    function postReply(commentId) {
        var replyInput = document.querySelector('.reply-input[data-comment-id="' + commentId + '"]');
        var replyText = replyInput.value.trim();
        if (replyText === "") {
            alert("Please enter a reply.");
            return;
        }

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                // Reload comments section after posting reply
                viewComments(document.getElementById('eventId').value);
                // Clear reply input
                replyInput.value = "";
            }
        };
        xhttp.open("POST", "post_reply.php", true);
        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhttp.send("commentId=" + encodeURIComponent(commentId) + "&reply=" + encodeURIComponent(replyText));
    }
</script>
</body>
</html>
