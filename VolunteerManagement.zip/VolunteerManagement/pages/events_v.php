<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Include database connection file
include_once "../includes/db.php";

// Query to fetch events added by the manager
$sql = "SELECT * FROM event";

// Query to fetch events joined by the current volunteer
$volunteerUsername = $_SESSION['username'];
$joinedEventsQuery = "SELECT e.* FROM event e JOIN task t ON e.event_id = t.event_id WHERE t.volunteer_username = '$volunteerUsername'";

$result = $conn->query($sql);
$joinedEventsResult = $conn->query($joinedEventsQuery);
$joinedEventIds = [];
if ($joinedEventsResult->num_rows > 0) {
    while ($row = $joinedEventsResult->fetch_assoc()) {
        $joinedEventIds[] = $row['event_id'];
    }
}

// Assume initially that no events are joined
$noEventsJoined = true;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Volunteer's Dashboard - Volunteer Management System</title>
    <link rel="stylesheet" href="../css/style2.css"> <!-- Assuming you have a CSS file for styling -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> <!-- Link to Font Awesome for icons -->
    <style>
        /* Your existing CSS styles */
        /* Add or modify styles for the event feed */
        .event {
            position: relative; /* Ensure positioning for buttons */
            border: 1px solid #ddd;
            margin-bottom: 20px;
            padding: 15px;
            color: #000;
            border-radius: 10px;
        }

        .event h3 {
            margin-top: 0;
        }

        .event p {
            margin-bottom: 10px;
        }

        .event-buttons {
            position: absolute;
            top: 10px;
            right: 10px;
        }

        .join-btn {
            background-color: #0A6522; /* Dark blue color for join button */
            color: #fff;
            border: none;
            padding: 10px 20px; /* Adjusted padding to make the button bigger */
            cursor: pointer;
            border-radius: 5px;
        }

        .join-btn i {
            margin-right: 5px;
        }

        .join-btn:hover {
            opacity: 0.8; /* Reduce opacity on hover */
        }

        .joined {
            background-color: #ccc; /* Gray color for joined event button */
            cursor: not-allowed; /* Change cursor to not-allowed */
        }

        .container {
            width: 100%;
            margin: 5px auto;
            display: flex;
            flex-direction: row; /* Arrange items horizontally */

        }

        .sidebar {
            flex: 1; /* Take 1/4 of the container */
            background-color: #FFD800; /* Updated background color */
            color: #000; /* Updated font color */
            padding: 0px;
            font-size: 18px; /* Adjust the font size for sidebar menu */
        }

        .menu {
            list-style-type: none;
            padding: 0px;
        }

        .menu a {
            display: block;
            text-decoration: none;
            color: #000; /* Updated font color */
            padding: 30px;
            border-bottom: 1px solid #555;
            transition: background-color 0.3s ease;
        }

        .menu a:hover {
            background-color: #363636;
            color: #fff;
        }

        .logout-link i {
            margin-right: 5px; /* Add a margin between icon and text */
        }

        .content {
            flex: 3; /* Take 3/4 of the container */
            padding: 20px;
            background-color: #fff;
        }

        h2 {
            color: #000;
            text-align: center;
        }

        /* Additional styles for description */
        .event-description {
            margin-bottom: 10px;
        }

        .event-description ul {
            margin-top: 0;
            padding-left: 20px; /* Indent the bullet points */
        }

        .event-description li {
            margin-bottom: 5px;
        }

        /* Styles for comment button */
        .comment-btn {
            background-color: #1877f2;
            color: #fff;
            border: none;
            padding: 10px 40px;
            border-radius: 5px;
            cursor: pointer;
            position: ;
            bottom: 10px; /* Adjusted position */
            left: 10px;
        }

        .comment-btn i {
            margin-right: 5px;
        }

        .comment-btn:hover {
            opacity: 0.8;
        }
        
        .floating-container {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
            z-index: 9999;
            width: 50%; /* Adjust the width as needed */
            max-height: 80%; /* Adjust the maximum height as needed */
            overflow-y: auto; /* Add scrollbar if content exceeds maximum height */
        }   

        .close-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            cursor: pointer;
            color: #777;
        }

        /* Styles to disable sidebar and event feed when floating container is open */
        .disable-sidebar, .disable-event-feed {
            pointer-events: none; /* Disable pointer events */
            opacity: 0.5; /* Reduce opacity to visually indicate that it's not clickable */
        }

        /* Additional styles for comments and replies */
        .comment-list {
            list-style-type: none;
            padding-left: 0;
        }

        .comment-list li {
            margin-bottom: 15px;
        }

        .reply-list {
            list-style-type: none;
            padding-left: 20px;
            margin-top: 10px;
        }
    </style>
</head>
<body>
<header>
    <h1>Volunteer Management System</h1>
</header>

<div class="container">
    <div class="sidebar">
        <h2>Welcome, <?php echo isset($_SESSION['username']) ? $_SESSION['username'] : "Guest"; ?>!</h2>
        <ul class="menu">
            <li><a href="dashboard_v.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href=""><i class="fas fa-calendar"></i> Events</a></li>
            <li><a href="#" onclick="loadMyTasks()"><i class="fas fa-tasks"></i> My Task</a></li>
            <li><a href="#" onclick="loadNotifications()"><i class="fas fa-bell"></i> Notification</a></li>
            <li><a href="#" onclick="loadVolunteerProfile()"><i class="fas fa-user"></i> Profile</a></li>
            <li class="logout-link"><a href="../index.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </div>
    <div class="content" id="dashboardContent">
        <!-- Display Events Feed -->
        <h2>All Events</h2>
        <?php
        if (isset($result) && $result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $eventId = $row['event_id'];
                if (in_array($eventId, $joinedEventIds)) {
                    continue; // Skip this event if volunteer has already joined
                }
                $eventName = $row["event_name"];
                $manager = $row["manager_fullname"];
                $startDate = $row["start_date"]; // Updated from event_date
                $endDate = $row["end_date"]; // Updated from event_date
                $startTime = $row["start_time"];
                $endTime = $row["end_time"];
                $volunteersNeeded = $row["no_of_volunteers"];
                $description = $row["description"];

                // Echo the event container with an id based on event_id
                echo "<div class='event' id='event_$eventId'>";
                echo "<div class='event-buttons'>";
                // Display join button for events not yet joined
                echo "<button class='join-btn' onclick='confirmJoin($eventId, this)'><i class='fas fa-plus-circle'></i> Join</button>";
                echo "</div>";
                echo " <h3>Event Name: $eventName</h3>";
                echo "<div class='event-description'><p><strong>Description:</strong></p>"; // Display event description
                // Split the description by new lines and display each line as a list item
                echo "<ul>"; // Start unordered list
                $description_lines = explode("\n", $description);
                foreach($description_lines as $line) {
                    echo "<li>$line</li>"; // Display each line as a list item
                }
                echo "</ul></div>"; // End unordered list and event-description div
                echo "<p><strong>Manager:</strong> $manager</p>";
                echo "<p><strong>Start Date:</strong> $startDate</p>";
                echo "<p><strong>End Date:</strong> $endDate</p>";
                echo "<p><strong>Start Time:</strong> $startTime</p>";
                echo "<p><strong>End Time:</strong> $endTime</p>";
                echo "<p><strong>Volunteers Needed:</strong> $volunteersNeeded</p>";
                // Add the Comment and Joined buttons with icons
                    echo "<div class='event-actions'>";
                    echo "<button class='comment-btn' onclick='viewComments(\"".$row["event_id"]."\")'><i class='far fa-comment'></i> Comment</button>";
                    echo "</div>"; // Close event-actions div
                    echo "</div>";

                // At least one event is displayed, so set $noEventsJoined to false
                $noEventsJoined = false;
            }
        }

        // Check if no events are joined
        if ($noEventsJoined) {
            echo "<p>No events added yet.</p>";
        }
        ?>
    </div>

</div>

<footer>    
    <p>Volunteer Management System</p>
    <p>This project is developed by Mark Anthony Estopa</p>
</footer>

<!-- JavaScript code -->
<script>
    // Function to handle joining event
    function joinEvent(eventId, eventElement) {
        var volunteerUsername = "<?php echo $_SESSION['username']; ?>"; // Get volunteer username from session

        // Send AJAX request to save join event information into database
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                alert("You have joined the event successfully!");
                // Reload the page
                loadMyTasks();
            }
        };
        xhttp.open("POST", "save_join_event.php", true);
        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        
        // Get current date and time
        var now = new Date();
        var joinedAt = now.toISOString(); // Convert to ISO string format
        
        // Construct data to send in the POST request
        var data = "eventId=" + eventId + "&joinedAt=" + joinedAt;
        
        // Send the request
        xhttp.send(data);
    }

    // Function to confirm joining event
    function confirmJoin(eventId, eventElement) {
        // Ask for confirmation
        if (confirm("Do you really want to join?")) {
            joinEvent(eventId, eventElement); // Pass event element to joinEvent function if user confirms
        }
    }

    // Function to load manager profile
    function loadVolunteerProfile() {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("dashboardContent").innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", "volunteer_profile.php", true);
        xhttp.send();
    }

    // Function to load My Tasks
    function loadMyTasks() {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("dashboardContent").innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", "my_tasks.php", true);
        xhttp.send();
    }

    // Function to handle withdrawing from task
    function withdrawTask(taskId) {
        if (confirm("Do you really want to withdraw from this task?")) {
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    // Reload the page to reflect changes
                    window.location.reload();
                }
            };
            xhttp.open("POST", "withdraw_task.php", true);
            xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhttp.send("taskId=" + taskId);
        }
    }

    // Function to load Notifications
    function loadNotifications() {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("dashboardContent").innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", "notifications_v.php", true);
        xhttp.send();
    }

    // Function to load Dashboard content
    function loadEventsContent() {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("dashboardContent").innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", "dashboard_content_v.php", true);
        xhttp.send();
    }

        function closeCommentContainer() {
        var commentContainer = document.querySelector('.floating-container');
        if (commentContainer) {
            document.body.removeChild(commentContainer);
            document.querySelector('.content').classList.remove('disable-event-feed');
            document.querySelector('.sidebar').classList.remove('disable-sidebar');
        }
    }

    // Function to post a comment
    function postComment() {
        var eventId = document.getElementById("eventId").value;
        var comment = document.getElementById("commentInput").value.trim();
        if (comment === "") {
            alert("Please enter a comment.");
            return;
        }

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                // Reload comments section after posting comment
                viewComments(eventId);
                // Close comment container
                closeCommentContainer();
            }
        };
        xhttp.open("POST", "post_comment.php", true);
        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhttp.send("eventId=" + encodeURIComponent(eventId) + "&comment=" + encodeURIComponent(comment));
    }

    // Function to view comments
    function viewComments(eventId) {
        // Close any existing comment containers
        closeCommentContainer();

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                // Display the response in a floating container
                var commentContainer = document.createElement("div");
                commentContainer.className = "floating-container";
                commentContainer.innerHTML = this.responseText;
                document.body.appendChild(commentContainer);
                
                // Add close button functionality
                var closeButton = document.createElement("span");
                closeButton.className = "close-btn";
                closeButton.innerHTML = "&times;";
                closeButton.onclick = closeCommentContainer;
                commentContainer.appendChild(closeButton);
                
                // Disable event feed and sidebar
                document.querySelector('.content').classList.add('disable-event-feed');
                document.querySelector('.sidebar').classList.add('disable-sidebar');
            }
        };
        xhttp.open("GET", "view_comments.php?eventId=" + eventId, true);
        xhttp.send();
    }
    // Function to post a reply
    function postReply(commentId) {
        var replyInput = document.querySelector('.reply-input[data-comment-id="' + commentId + '"]');
        var replyText = replyInput.value.trim();
        if (replyText === "") {
            alert("Please enter a reply.");
            return;
        }

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                // Reload comments section after posting reply
                viewComments(document.getElementById('eventId').value);
                // Clear reply input
                replyInput.value = "";
            }
        };
        xhttp.open("POST", "post_reply.php", true);
        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhttp.send("commentId=" + encodeURIComponent(commentId) + "&reply=" + encodeURIComponent(replyText));
    }
</script>

</body>
</html>
            