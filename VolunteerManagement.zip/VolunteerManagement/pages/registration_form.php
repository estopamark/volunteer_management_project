<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Registration</title>
    <link rel="stylesheet" href="../pages/style1.css">
    <style>
        body {
            background-image: url(background.jpg);
            background-size: cover;
            background-repeat: no-repeat;
            margin: 0;
            padding: 0;
        }
        .h2 {
            text-align: center; /* Center the Login label */
            text-shadow: 2px 2px 4px rgba(50, 50, 50, 0.7); 
        }
        .center {
            text-align: center;
        }
        .showpass1 {
            font-style: italic;
        }
        .showpass2 {
            font-style: italic;
        }
        .password-info {
            color: #888;
            font-size: 12px;
            margin-top: 5px;
        }
        .email-info,
        .username-info {
            color: red;
            font-size: 12px;
            margin-top: 5px;
            display: none; /* Initially hidden */
        }
    </style>
</head>
<body>
    <h2>REGISTRATION</h2>
    <form action="register.php" method="post" onsubmit="return validateForm()">
        <!-- User Type -->
        <div class="input-group">
            <label for="user_type">User Type</label>
            <select name="user_type" id="user_type" class="styled-select" required>
                <option value="">-Select-</option> <!-- changed value to empty string -->
                <option value="volunteer">Volunteer</option>
                <option value="manager">Manager</option>
            </select>
        </div>
        <!-- Full Name -->
        <label for="fullname">Full Name</label>    
        <input type="text" name="fullname" id="fullname" placeholder="Enter your full name" required oninput="validateForm()">
        <!-- Email -->
        <label for="email">Email</label>
        <input type="email" name="email" id="email" placeholder="Enter your email address" required oninput="validateEmail()">
        <div class="email-info" id="email_info"></div> <!-- Display message if email is taken -->
        <!-- Contact No -->
        <label for="contact_no">Contact No</label>
        <input type="text" name="contact_no" id="contact_no" placeholder="Enter your contact number" maxlength="11">
        <!-- Username -->
        <label for="username">Username</label>
        <input type="text" name="username" id="username" placeholder="Enter your username" required oninput="validateUsername()">
        <div class="username-info" id="username_info"></div> <!-- Display message if username is taken -->
        <!-- Password -->
        <label for="password">Password</label>
        <input type="password" name="password" id="password" placeholder="Enter your password" required oninput="validatePassword(this); validateForm()">
        <a class="showpass1"><input type="checkbox" onclick="togglePasswordVisibility('password')"> Show Password</a><br>
        <div class="password-info" id="password_info"></div><br>
        
        <!-- Confirm Password -->
        <label for="confirm_password">Confirm Password</label>
        <input type="password" name="confirm_password" id="confirm_password" placeholder="Confirm your password" required oninput="checkPasswordMatch(this); validateForm()">
        <a class="showpass2"><input type="checkbox" onclick="togglePasswordVisibility('confirm_password')"> Show Password</a><br>
        <div class="password-info" id="confirm_password_info"></div><br>
        
        <!-- Submit Button -->
        <input type="submit" value="Submit" id="submit_button" disabled>
        
        <div class="center">
            <label for="login_link">Do you have an account? <a href="../index.php">Click here to login</a></label><br>
        </div>
    </form>

    <script type="text/javascript">

        // Function to validate numeric input for contact number
        document.getElementById("contact_no").addEventListener("input", function(event) {
            var input = event.target.value;
            if (!/^\d*$/.test(input)) {
                event.target.value = input.slice(0, -1);
            }
        });
        
        function validateEmail() {
        var emailInput = document.getElementById("email");
        var emailInfo = document.getElementById("email_info");
        var email = emailInput.value.trim(); 
        var userType = document.getElementById("user_type").value;

        // Check if email is not empty and is valid
        if (email !== "") {
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_email.php", true);
            xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    if (xhr.responseText === "taken") {
                        emailInfo.textContent = "Email is already taken";
                        emailInfo.style.display = "block";
                        emailInput.setCustomValidity("Email is already taken");
                    } else {
                        emailInfo.textContent = "";
                        emailInfo.style.display = "none";
                        emailInput.setCustomValidity("");
                    }
                }
            };
            xhr.send("email=" + email + "&user_type=" + userType);
        } else {
            emailInfo.textContent = "";
            emailInfo.style.display = "none";
            emailInput.setCustomValidity("");
        }
    }

        function validateUsername() {
        var usernameInput = document.getElementById("username");
        var usernameInfo = document.getElementById("username_info");
        var username = usernameInput.value.trim(); 
        var userType = document.getElementById("user_type").value;

        // Check if username is not empty
        if (username !== "") {
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "check_username.php", true);
            xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    if (xhr.responseText === "taken") {
                        usernameInfo.textContent = "Username is already taken";
                        usernameInfo.style.display = "block";
                        usernameInput.setCustomValidity("Username is already taken");
                    } else {
                        usernameInfo.textContent = "";
                        usernameInfo.style.display = "none";
                        usernameInput.setCustomValidity("");
                    }
                }
            };
            xhr.send("username=" + username + "&user_type=" + userType);
        } else {
            usernameInfo.textContent = "";
            usernameInfo.style.display = "none";
            usernameInput.setCustomValidity("");
        }
    }

        // Function to validate form before submission
        function validateForm() {
            var userType = document.getElementById("user_type").value;
            var contactNo = document.getElementById("contact_no").value;
            var password = document.getElementById("password").value;
            var confirmPassword = document.getElementById("confirm_password").value;
            var passwordInfo = document.getElementById("password_info");
            var submitButton = document.getElementById("submit_button");

            // Check if any field is empty
            if (userType === "" || contactNo === "" || password === "" || confirmPassword === "") {
                submitButton.disabled = true;
                return false;
            } else if (passwordInfo.textContent.trim() !== "✓ Strong Password") {
                submitButton.disabled = true;
                return false;
            } else {
                submitButton.disabled = false;
                return true;
            }
        }

        // JavaScript function to toggle password visibility
        function togglePasswordVisibility(inputId) {
            var passwordField = document.getElementById(inputId);
            if (passwordField.type === "password") {
                passwordField.type = "text";
            } else {
                passwordField.type = "password";
            }
        }

        // JavaScript function to validate password
        function validatePassword(passwordInput) {
            var password = passwordInput.value;
            var passwordInfo = document.getElementById("password_info");

            // Validate password rules
            var validPassword = true;
            if (password.length < 8 || password.length > 20) {
                validPassword = false;
                passwordInfo.textContent = "Password must be 8-20 characters";
            } else if (!/[!@#$%^&*()_+\-={}\[\]|:;<>?,./~]/.test(password)) {
                validPassword = false;
                passwordInfo.textContent = "At least one special character";
            } else if (!/[A-Z]/.test(password)) {
                validPassword = false;
                passwordInfo.textContent = "At least one capital letter";
            } else if (!/[0-9]/.test(password)) {
                validPassword = false;
                passwordInfo.textContent = "At least one number";
            } else {
                passwordInfo.textContent = "✓ Strong Password";
            }

            if (validPassword) {
                passwordInfo.style.color = "green";
            } else {
                passwordInfo.style.color = "red";
            }

            validateForm();
        }

        // JavaScript function to check password match
        function checkPasswordMatch(confirmPasswordInput) {
            var confirmPassword = confirmPasswordInput.value;
            var password = document.getElementById("password").value;
            var confirmPasswordInfo = document.getElementById("confirm_password_info");

            if (password === confirmPassword) {
                confirmPasswordInfo.textContent = "✓ Password match";
                confirmPasswordInfo.style.color = "green";
            } else {
                confirmPasswordInfo.textContent = "Password didn't match";
                confirmPasswordInfo.style.color = "red";
            }

            validateForm();
        }

    </script>

</body>
</html>
