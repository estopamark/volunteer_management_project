<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include_once "../includes/db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['managerId'])) {
    $managerId = $_POST['managerId'];
    
    // SQL to delete manager
    $sql = "DELETE FROM manager WHERE id = $managerId";

    if ($conn->query($sql) === TRUE) {
        echo "Manager deleted successfully";
    } else {
        echo "Error deleting manager: " . $conn->error;
    }

    $conn->close();
} else {
    echo "Invalid request";
}
?>
