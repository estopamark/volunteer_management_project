<?php
// Include database connection file
include_once "../includes/db.php";

// Get event ID from POST request
$eventId = $_POST['event_id'];

// Retrieve event details for notification
$eventQuery = $conn->prepare("SELECT * FROM event WHERE event_id = ?");
$eventQuery->bind_param("i", $eventId);
$eventQuery->execute();
$eventResult = $eventQuery->get_result();

if ($eventResult->num_rows > 0) {
    $eventData = $eventResult->fetch_assoc();
    $eventName = $eventData['event_name'];
    $managerFullName = $eventData['manager_fullname'];

    // Insert notification for volunteers about event deletion
    $notifyVolunteersQuery = $conn->prepare("INSERT INTO notifications_v (manager_fullname, event_name, deleted_at) VALUES (?, ?, NOW())");
    $notifyVolunteersQuery->bind_param("ss", $managerFullName, $eventName);
    $notifyVolunteersQuery->execute();
}

// Close database connection
$conn->close();
?>
