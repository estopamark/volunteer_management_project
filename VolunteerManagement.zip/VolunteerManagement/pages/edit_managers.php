<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include_once "../includes/db.php";

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['managerId'])) {
    $managerId = $_GET['managerId'];

    // Retrieve manager information from the database
    $sql = "SELECT * FROM manager WHERE id = $managerId";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $fullname = $row['fullname'];
        $email = $row['email'];
        $contact_no = $row['contact_no'];
    } else {
        echo "<script>alert('Manager not found');</script>";
        exit();
    }
} elseif ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['managerId'])) {
    $managerId = $_POST['managerId'];
    $fullname = $conn->real_escape_string($_POST['fullname']);
    $email = $conn->real_escape_string($_POST['email']);
    $contact_no = $_POST['contact_no'];

    // Validate contact number (must be numeric and exactly 11 digits)
    if (!preg_match('/^\d{11}$/', $contact_no)) {
        echo "<script>alert('Invalid contact number. Please enter 11 digits only.');</script>";
        exit();
    }

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Invalid email address. Please enter a valid email address.');</script>";
        exit();
    }

    // Update manager information in the database
    $sql = "UPDATE manager SET fullname='$fullname', email='$email', contact_no='$contact_no' WHERE id=$managerId";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Manager information updated successfully!'); window.location.href='managers.php';</script>";
        exit();
    } else {
        echo "<script>alert('Error updating manager information: " . $conn->error . "');</script>";
    }
} else {
    echo "<script>alert('Invalid request');</script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Manager - Volunteer Management System</title>
    <link rel="stylesheet" href="../css/style2.css">
    <style>
        /* Center the form */
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 80vh;
            width: 500px;
        }

        /* Style the form */
        .content {
            width: 400px;
            padding: 40px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        /* Style the form labels */
        label {
            display: block;
            margin-bottom: 10px;
        }

        /* Style the form input fields */
        input[type="text"],
        input[type="email"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        /* Style the Update button */
        input[type="submit"] {
            background-color: green; /* Change background color to green */
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: darkgreen; /* Darken background color on hover */
        }

        /* Center the Update button */
        .button-container {
            text-align: center;
        }
    </style>
</head>
<body>
    <header>
        <h1>Volunteer Management System</h1>
    </header>

    <div class="container">
        <div class="content">
            <h2>Edit Manager Information</h2>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <input type="hidden" name="managerId" value="<?php echo $managerId; ?>">
                <label for="fullname">Full Name</label>
                <input type="text" name="fullname" id="fullname" value="<?php echo $fullname; ?>" required><br>
                <label for="email">Email</label>
                <input type="email" name="email" id="email" value="<?php echo $email; ?>" required><br>
                <label for="contact_no">Contact No</label>
                <input type="text" name="contact_no" id="contact_no" value="<?php echo $contact_no; ?>" maxlength="11" required><br>
                <!-- Wrap the Update button inside a div with text-align: center -->
                <div class="button-container">
                    <input type="submit" value="Update">
                </div>
            </form>
        </div>
    </div>

    <footer>    
        <p>Volunteer Management System</p>
        <p>This project is developed by Mark Anthony Estopa</p>
    </footer>
    <script type="text/javascript">

        // Function to validate numeric input for contact number
        document.getElementById("contact_no").addEventListener("input", function(event) {
            var input = event.target.value;
            if (!/^\d*$/.test(input)) {
                event.target.value = input.slice(0, -1);
            }
        });
    </script>
</body>
</html>
