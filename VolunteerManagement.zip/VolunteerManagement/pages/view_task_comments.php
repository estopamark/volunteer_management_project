<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Include database connection file
include_once "../includes/db.php";

if (isset($_GET['taskId'])) {
    $taskId = mysqli_real_escape_string($conn, $_GET['taskId']);

    // Fetch comments for the task with username and fullname
    $query = "SELECT c.*, m.fullname FROM task_comments c JOIN manager m ON c.username = m.username WHERE c.task_id = '$taskId' ORDER BY c.created_at DESC";
    $result = mysqli_query($conn, $query);

    echo "<h2>Comments for Task #$taskId</h2>";

    // Display comment form
    echo "<form id='commentForm'>";
    echo "<input type='hidden' id='taskId' value='$taskId'>";
    echo "<textarea id='commentInput' placeholder='Write a comment...' rows='2' cols='50'></textarea>";
    echo "<button type='button' onclick='postTaskComment()'><i class='fas fa-paper-plane'></i></button>";
    echo "</form>";

    if ($result && mysqli_num_rows($result) > 0) {
        // Display comments
        echo "<ul class='comment-list'>";
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<li><strong>{$row['fullname']}:</strong> {$row['comment_text']}</li>";
        }
        echo "</ul>"; // Close comment-list
    } else {
        echo "<p>No comments available for this task.</p>";
    }
} else {
    echo "<p>Error: Task ID not provided.</p>";
}

mysqli_close($conn);
?>
