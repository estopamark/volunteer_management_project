<?php
// Include database connection file
include_once "../includes/db.php";

// Check if the comment form is submitted
if(isset($_POST['comment']) && isset($_POST['event_id'])) {
    // Sanitize input
    $comment = htmlspecialchars($_POST['comment']);
    $event_id = $_POST['event_id'];
    // Insert the comment into the database
    $stmt = $conn->prepare("INSERT INTO comments (event_id, comment) VALUES (?, ?)");
    $stmt->bind_param("is", $event_id, $comment);
    $stmt->execute();
    $stmt->close();
}

// Fetch comments for a specific event
if(isset($_GET['event_id'])) {
    $event_id = $_GET['event_id'];
    $sql = "SELECT * FROM comments WHERE event_id = '$event_id'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "<p>" . $row["comment"] . "</p>";
        }
    } else {
        echo "No comments yet.";
    }
}
?>
