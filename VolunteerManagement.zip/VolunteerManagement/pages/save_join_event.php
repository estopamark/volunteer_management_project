<?php
session_start();

if (!isset($_SESSION['username'])) {
    // If user is not logged in, redirect to login page
    header("Location: login.php");
    exit();
}

// Include database connection file
include_once "../includes/db.php";

// Check if eventId and volunteerUsername are set in the POST request
if (isset($_POST['eventId']) && isset($_SESSION['username'])) {
    // Sanitize input data
    $eventId = mysqli_real_escape_string($conn, $_POST['eventId']);
    $volunteerUsername = $_SESSION['username'];

    // Retrieve volunteer fullname from the volunteers table based on username
    $volunteerFullnameQuery = "SELECT fullname FROM volunteers WHERE username = '$volunteerUsername'";
    $volunteerFullnameResult = mysqli_query($conn, $volunteerFullnameQuery);

    if ($volunteerFullnameResult && mysqli_num_rows($volunteerFullnameResult) > 0) {
        $row = mysqli_fetch_assoc($volunteerFullnameResult);
        $volunteerFullname = $row['fullname'];
    } else {
        $volunteerFullname = ""; // Set empty string if fullname not found
    }

    // Get start date and end date of the event
    $eventDateQuery = "SELECT start_date, end_date, start_time, end_time FROM event WHERE event_id = '$eventId'";
    $eventDateResult = mysqli_query($conn, $eventDateQuery);

    if ($eventDateResult && mysqli_num_rows($eventDateResult) > 0) {
        $row = mysqli_fetch_assoc($eventDateResult);
        $startDate = $row['start_date'];
        $endDate = $row['end_date'];
        $startTime = strtotime($row['start_time']);
        $endTime = strtotime($row['end_time']);

        // Calculate total hours for each day between start date and end date
        $currentDate = strtotime($startDate);
        $totalHours = 0;
        while ($currentDate <= strtotime($endDate)) {
            // Calculate start and end timestamps for the current day
            $dayStartTime = strtotime(date('Y-m-d', $currentDate) . ' ' . date('H:i:s', $startTime));
            $dayEndTime = strtotime(date('Y-m-d', $currentDate) . ' ' . date('H:i:s', $endTime));

            // Calculate hours for the current day
            $dayHours = round(($dayEndTime - $dayStartTime) / 3600, 2); // Convert seconds to hours
            $totalHours += $dayHours;

            // Move to the next day
            $currentDate = strtotime('+1 day', $currentDate);
        }

        // Update the number of volunteers needed for the event
        $updateQuery = "UPDATE event SET no_of_volunteers = no_of_volunteers - 1, volunteers = CONCAT_WS('\n', '$volunteerFullname', volunteers) WHERE event_id = '$eventId'";
        if (mysqli_query($conn, $updateQuery)) {
            // Insert into task table
            $insertQuery = "INSERT INTO task (volunteer_username, volunteer_fullname, event_id, joined_at, total_hours) 
                            VALUES ('$volunteerUsername', '$volunteerFullname', '$eventId', NOW(), '$totalHours')";
            if (mysqli_query($conn, $insertQuery)) {
                // If insertion is successful, commit the transaction
                mysqli_commit($conn);
                echo "Event joined successfully!";
            } else {
                // If insertion fails, rollback the transaction
                mysqli_rollback($conn);
                echo "Error: " . mysqli_error($conn);
            }
        } else {
            // If update fails, rollback the transaction
            mysqli_rollback($conn);
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        echo "Error: Could not fetch event details.";
    }
} else {
    // If eventId or volunteerUsername is not set, send error response
    echo "Error: eventId and volunteerUsername are required.";
}

// Close database connection
mysqli_close($conn);
?>
