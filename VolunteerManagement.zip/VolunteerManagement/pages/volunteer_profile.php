<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include_once "../includes/db.php";

// Retrieve volunteer's information from the database
$username = $_SESSION['username'];
$sql = "SELECT * FROM volunteers WHERE username='$username'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Volunteer found, fetch data
    $volunteer_data = $result->fetch_assoc();
} else {
    // Volunteer not found
    echo "Volunteer data not found!";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Volunteer Profile - Volunteer Management System</title>
    <link rel="stylesheet" href="../css/style.css"> <!-- Assuming you have a CSS file for styling -->
    <style>
        /* CSS for volunteer_profile.php */

        /* General styles for profile container */
        .profile-container {
            width: 60%;
            height: 40vh;
            margin: 80px auto;
            padding: 50px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f9f9f9;
        }

        /* Styles for profile form */
        .profile-form {
            max-width: 400px;
            margin: 0 auto;
        }

        /* Styles for form labels */    
        .profile-form label {
            display: block;
            margin-bottom: 15px;
            color: #333;
            font-weight: bold;
        }

        /* Styles for form inputs */
        .profile-form input[type="text"],
        .profile-form input[type="email"],
        .profile-form input[type="tel"] {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        /* Styles for form inputs in readonly state */
        .profile-form input[readonly] {
            background-color: #eee;
            cursor: not-allowed;
        }

        /* Optional: Adjust font styles */
        body {
            font-family: Arial, sans-serif;
            font-size: 16px;
            line-height: 1.6;
            color: #333;
        }
        h2 {
            color: #000;
            text-align: center;
        }
        .sidebar {
        flex: 1; /* Take 1/4 of the container */
        background-color: #FFD800; /* Updated background color */
        color: #000; /* Updated font color */
        padding: 0px;
        font-size: 18px; /* Adjust the font size for sidebar menu */
        }

        .menu {
            list-style-type: none;
            padding: 0px;
        }

        .menu a {
            display: block;
            text-decoration: none;
            color: #000; /* Updated font color */
            padding: 30px;
            border-bottom: 1px solid #555;
            transition: background-color 0.3s ease;
        }

        .menu a:hover {
            background-color: #363636;
            color: #fff;
        }
    </style>
</head>
<body>

<h2>Personal Information</h2>
<div class="profile-container">
    <form class="profile-form" method="post" action="#">
        <label for="full_name">Name</label>
        <input type="text" id="full_name" name="full_name" value="<?php echo $volunteer_data['fullname']; ?>" readonly>
        <br>
        <label for="email">Email</label>
        <input type="email" id="email" name="email" value="<?php echo $volunteer_data['email']; ?>" readonly>
        <br>
        <label for="contact_no">Contact No</label>
        <input type="tel" id="contact_no" name="contact_no" value="<?php echo $volunteer_data['contact_no']; ?>" readonly>
    </form>
</div>

</body>
</html>
