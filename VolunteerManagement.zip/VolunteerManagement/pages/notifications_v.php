<?php
// Start the session to access session variables
session_start();

// Include the file that establishes the database connection
include_once "../includes/db.php";

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Make sure $conn is defined and not null
if(isset($conn)) {
    // Modify the SQL query to fetch notifications from notifications_v table and order by created_at
    $sql = "SELECT * FROM notifications_v ORDER BY CASE
        WHEN created_at IS NOT NULL THEN created_at
        WHEN deleted_at IS NOT NULL THEN deleted_at
        END DESC"; // Order by created_at or deleted_at in descending order to get recent notifications first
    $result = $conn->query($sql);

    // Display notifications
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Format notification information
            $managerName = "<strong>{$row['manager_fullname']}</strong>";
            $eventName = "<strong>'{$row['event_name']}'</strong>";
            $notificationInfo = ""; // Notification message initialization
            
            // Check if the event exists
            $eventNameForQuery = $row['event_name'];
            $eventQuery = $conn->query("SELECT event_id FROM event WHERE event_name = '$eventNameForQuery'");
            $eventRow = $eventQuery->fetch_assoc();
            $eventId = $eventRow ? $eventRow['event_id'] : null;

            if ($eventId) {
                // Event exists
                // Check if the notification is for a created event or a deleted event
                if ($row['created_at'] !== null) {
                    // Notification is for a created event
                    $createdAt = date("F j, Y, g:i a", strtotime($row['created_at'])); // Format the datetime
                    $notificationInfo = "$managerName created an event '$eventName'."; // Updated notification message
                } elseif ($row['deleted_at'] !== null) {
                    // Notification is for a deleted event
                    $deletedAt = date("F j, Y, g:i a", strtotime($row['deleted_at'])); // Format the datetime
                    $notificationInfo = "$managerName deleted an event '$eventName'."; // Updated notification message
                }
                
                // Check if the volunteer has already joined the event
                if (!empty($notificationInfo)) {
                    $volunteerUsername = $_SESSION['username'];
                    $joinCheckQuery = $conn->query("SELECT * FROM task WHERE event_id = $eventId AND volunteer_username = '$volunteerUsername'");
                    if ($joinCheckQuery && $joinCheckQuery->num_rows > 0) {
                        // Volunteer has already joined the event
                        echo "<div style='border: 5px solid #ddd; padding: 10px; margin-bottom: 10px; border-radius: 10px;'>";
                        echo "<p>You have already joined the event '$eventName'.</p>";
                        echo "</div>";
                    } else {    
                        // Volunteer has not joined the event, display the notification
                        // Start anchor tag to make the entire notification container clickable
                        echo "<a href='events_v.php?event_id=$eventId#event_$eventId' style='text-decoration: none; color: inherit;'>"; 
                        // Start notification container
                        echo "<div style='border: 5px solid #ddd; padding: 10px; margin-bottom: 10px; border-radius: 10px;'>";
                        // Display notification information
                        echo "<p>$notificationInfo</p>"; 
                        if ($row['created_at'] !== null) {
                            // Display creation date
                            echo "<p>Created at: $createdAt</p>";
                        } elseif ($row['deleted_at'] !== null) {
                            // Display deletion date
                            echo "<p>Deleted at: $deletedAt</p>";
                        }
                        // End notification container
                        echo "</div>";
                        // End anchor tag
                        echo "</a>";
                    }
                }
            } else {
                // Event does not exist, display notification directly from notifications_v table
                // Check if the notification is for a created event or a deleted event
                if ($row['created_at'] !== null) {
                    // Notification is for a created event
                    $createdAt = date("F j, Y, g:i a", strtotime($row['created_at'])); // Format the datetime
                    $notificationInfo = "$managerName created an event '$eventName'."; // Updated notification message
                } elseif ($row['deleted_at'] !== null) {
                    // Notification is for a deleted event
                    $deletedAt = date("F j, Y, g:i a", strtotime($row['deleted_at'])); // Format the datetime
                    $notificationInfo = "$managerName deleted an event '$eventName'."; // Updated notification message
                }
                
                // Display the notification directly
                echo "<div style='border: 5px solid #ddd; padding: 10px; margin-bottom: 10px; border-radius: 10px;'>";
                echo "<p>$notificationInfo</p>";
                if ($row['created_at'] !== null) {
                    // Display creation date
                    echo "<p>Created at: $createdAt</p>";
                } elseif ($row['deleted_at'] !== null) {
                    // Display deletion date
                    echo "<p>Deleted at: $deletedAt</p>";
                }
                echo "</div>";
            }
        }
    } else {
        echo "<p>No notifications.</p>";
    }
} else {
    echo "<p>Database connection error.</p>";
}
?>  