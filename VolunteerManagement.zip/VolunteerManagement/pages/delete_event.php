<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['event_id'])) {
    // Include database connection file
    include_once "../includes/db.php";

    // Get event ID
    $eventId = $_POST['event_id'];

    // Fetch event details including event name and manager username
    $stmt = $conn->prepare("SELECT event_name, manager_fullname, manager_username FROM event WHERE event_id = ?");
    $stmt->bind_param("i", $eventId);
    $stmt->execute();
    $stmt->bind_result($eventName, $managerFullname, $managerUsername);
    $stmt->fetch();
    $stmt->close();

    // Check if the logged-in manager's username matches the creator of the event
    if ($_SESSION['username'] !== $managerUsername) {
        // If not the creator, display error message using JavaScript
        echo "<script>alert('You don\\'t have permission to delete this event!'); window.location='dashboard_m.php';</script>";
        exit(); // Stop further execution
    }

    // Prepare and execute SQL query to delete tasks associated with the event
    $stmt = $conn->prepare("DELETE FROM task WHERE event_id = ?");
    $stmt->bind_param("i", $eventId);
    $stmt->execute();
    $stmt->close();

    // Prepare and execute SQL query to delete event from the database
    $stmt = $conn->prepare("DELETE FROM event WHERE event_id = ?");
    $stmt->bind_param("i", $eventId);
    $stmt->execute();
    $stmt->close();

    // Prepare and execute SQL query to insert notification of event deletion
    $stmt = $conn->prepare("INSERT INTO notifications_v (event_id, event_name, manager_fullname, deleted_at) VALUES (?, ?, ?, NOW())");
    $stmt->bind_param("iss", $eventId, $eventName, $managerFullname);
    $stmt->execute();
    $stmt->close();

    // Close database connection
    $conn->close();

    // Redirect to dashboard after deleting event
    header("Location: dashboard_m.php");
    exit();
} else {
    // Invalid request
    header("Location: dashboard_m.php");
    exit();
}
?>
