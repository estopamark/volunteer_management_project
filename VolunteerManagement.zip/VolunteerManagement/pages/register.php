<?php
include __DIR__ . '/../includes/db.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = $conn->real_escape_string($_POST['fullname']);
    $email = $conn->real_escape_string($_POST['email']);
    $username = $conn->real_escape_string($_POST['username']);
    $password = password_hash($conn->real_escape_string($_POST['password']), PASSWORD_DEFAULT);
    $user_type = $conn->real_escape_string($_POST['user_type']);
    $contact_no = $conn->real_escape_string($_POST['contact_no']);

    // Choose the table based on the user type
    $table_name = ($user_type === 'manager') ? 'manager' : 'volunteers';

    // Check if the email and username exist in the database
    $sql_check_email = "SELECT * FROM $table_name WHERE email=?";
    $sql_check_username = "SELECT * FROM $table_name WHERE username=?";
    
    // Using prepared statements to prevent SQL injection
    $stmt_check_email = $conn->prepare($sql_check_email);
    $stmt_check_email->bind_param("s", $email);
    $stmt_check_email->execute();
    $result_check_email = $stmt_check_email->get_result();
    
    $stmt_check_username = $conn->prepare($sql_check_username);
    $stmt_check_username->bind_param("s", $username);
    $stmt_check_username->execute();
    $result_check_username = $stmt_check_username->get_result();

    if ($result_check_email->num_rows > 0) {
        echo "Email is already taken";
    } elseif ($result_check_username->num_rows > 0) {
        echo "Username is already taken";
    } else {
        $sql = "INSERT INTO $table_name (fullname, email, contact_no, username, password) VALUES (?, ?, ?, ?, ?)";
        
        // Using prepared statement to insert data safely
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssss", $fullname, $email, $contact_no, $username, $password);
        
        if ($stmt->execute()) {
            echo "<script>alert('Registration successful!'); window.location.href='../index.php';</script>";
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}
?>
