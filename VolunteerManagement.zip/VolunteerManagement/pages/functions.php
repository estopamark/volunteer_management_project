<?php
// functions.php

// Function to get the count of unread notifications for the logged-in manager
function getUnreadNotificationsCount() {
    // Include database connection file
    include_once "db.php"; // Update the path if necessary

    // Retrieve the logged-in manager's username from the session
    $managerUsername = $_SESSION['username'];

    // Query to count the number of unread notifications
    $sql = "SELECT COUNT(*) AS unread_count FROM notifications WHERE manager_username = '$managerUsername' AND is_read = 0";

    // Execute the query
    $result = $conn->query($sql);

    // Check if query executed successfully
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $unreadCount = $row['unread_count'];
        return ($unreadCount > 0) ? " ($unreadCount)" : ""; // Return unread count if greater than 0, otherwise return an empty string
    } else {
        return ""; // Return empty string if no unread notifications found
    }

    // Close database connection
    $conn->close();
}
?>
