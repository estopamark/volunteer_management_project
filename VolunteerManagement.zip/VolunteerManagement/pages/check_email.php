<?php
include __DIR__ . '/../includes/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["email"], $_POST["user_type"])) {
    $email = $conn->real_escape_string($_POST["email"]);
    $user_type = $conn->real_escape_string($_POST["user_type"]);

    // Choose the table based on the user type
    $table_name = ($user_type === 'manager') ? 'manager' : 'volunteers';

    // Check if email already exists
    $check_email_query = "SELECT * FROM $table_name WHERE email='$email'";
    $check_email_result = $conn->query($check_email_query);

    if ($check_email_result->num_rows > 0) {
        echo "taken";
    } else {
        echo "available";
    }
}
?>
