<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Include database connection file
include_once "../includes/db.php";

if (isset($_GET['eventId'])) {
    $eventId = mysqli_real_escape_string($conn, $_GET['eventId']);

    $eventQuery = "SELECT event_name FROM event WHERE event_id = '$eventId'";
    $eventResult = mysqli_query($conn, $eventQuery);

    if ($eventResult && mysqli_num_rows($eventResult) > 0) {
        $eventRow = mysqli_fetch_assoc($eventResult);
        $eventName = $eventRow['event_name'];

        // Fetch comments for the event with username and fullname
        $query = "SELECT c.*, IFNULL(v.fullname, m.fullname) AS commenter_name 
                  FROM comments c 
                  LEFT JOIN manager m ON c.username = m.username 
                  LEFT JOIN volunteers v ON c.username = v.username 
                  WHERE c.event_id = '$eventId' 
                  ORDER BY c.created_at DESC";
        $result = mysqli_query($conn, $query);

        echo "<h2>Comments for $eventName</h2>";

        // Display comment form
        echo "<form id='commentForm'>";
        echo "<input type='hidden' id='eventId' value='$eventId'>";
        echo "<textarea id='commentInput' placeholder='Write a comment...' rows='2' cols='50'></textarea>";
        echo "<button type='button' onclick='postComment()'><i class='fas fa-paper-plane'></i></button>";
        echo "</form>";

        if ($result && mysqli_num_rows($result) > 0) {
            // Display comments
            echo "<ul class='comment-list'>";
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<li><strong>{$row['commenter_name']}:</strong> {$row['comment_text']}";

                // Reply functionality
                echo "<div class='reply-section'>";
                echo "<input type='text' class='reply-input' data-comment-id='{$row['comment_id']}' placeholder='Write a reply...'>";
                echo "<button class='send-reply-btn' onclick='postReply(\"{$row['comment_id']}\")'><i class='fas fa-paper-plane'></i></button>";
                echo "</div>";

                // Display replies if any
                $commentId = $row['comment_id'];
                $replyQuery = "SELECT r.*, IFNULL(v.fullname, m.fullname) AS replier_name 
                               FROM replies r 
                               LEFT JOIN manager m ON r.username = m.username 
                               LEFT JOIN volunteers v ON r.username = v.username 
                               WHERE r.comment_id = '$commentId' 
                               ORDER BY r.created_at ASC";
                $replyResult = mysqli_query($conn, $replyQuery);
                if ($replyResult && mysqli_num_rows($replyResult) > 0) {
                    echo "<ul class='reply-list'>";
                    while ($replyRow = mysqli_fetch_assoc($replyResult)) {
                        echo "<li><strong>{$replyRow['replier_name']}:</strong> {$replyRow['reply_text']}</li>";
                    }
                    echo "</ul>";
                }
                echo "</li>";
            }
            echo "</ul>";
        } else {
            echo "<p>No comments available for this event.</p>";
        }
    } else {
        echo "<p>Error: Event not found.</p>";
    }
} else {
    echo "<p>Error: Event ID not provided.</p>";
}

mysqli_close($conn);
?>
