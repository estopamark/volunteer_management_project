<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['event_id'])) {
    // Include database connection file
    include_once "../includes/db.php";

    // Get form data
    $eventId = $_POST['event_id'];
    $eventName = $_POST["event_name"];
    $eventDescription = $_POST["event_description"]; // Add description field
    $startDate = $_POST["start_date"];
    $endDate = $_POST["end_date"];
    $startTime = $_POST["start_time"];
    $endTime = $_POST["end_time"];
    $volunteers = $_POST["volunteers"];

    // Prepare and execute SQL query to update event in the database
    $stmt = $conn->prepare("UPDATE event SET event_name = ?, description = ?, start_date = ?, end_date = ?, start_time = ?, end_time = ?, no_of_volunteers = ? WHERE event_id = ?");
    $stmt->bind_param("sssssssi", $eventName, $eventDescription, $startDate, $endDate, $startTime, $endTime, $volunteers, $eventId);
    $stmt->execute();

    // Update notification for volunteers
    $stmt = $conn->prepare("UPDATE notifications_v SET event_name = ? WHERE event_name = ?");
    $stmt->bind_param("ss", $eventName, $eventName);
    $stmt->execute();

    // Close statement and database connection
    $stmt->close();
    $conn->close();

    // Redirect to dashboard after updating event
    header("Location: dashboard_a.php");
    exit();
} elseif ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['event_id'])) {
    // Fetch event details from the database
    include_once "../includes/db.php";

    $eventId = $_GET['event_id'];
    $sql = "SELECT * FROM event WHERE event_id = $eventId";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $eventName = $row['event_name'];
        $eventDescription = $row['description']; // Add description field
        $startDate = $row['start_date'];
        $endDate = $row['end_date'];
        $startTime = $row['start_time'];
        $endTime = $row['end_time'];
        $volunteers = $row['no_of_volunteers'];
    } else {
        // Event not found
        header("Location: dashboard_a.php");
        exit();
    }
} else {
    // Invalid request
    header("Location: dashboard_a.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Event - Volunteer Management System</title>
    <style>
        /* Your CSS styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-image: url(background.jpg);
            background-size: cover;
            background-repeat: no-repeat;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 400px;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        label {
            display: block;
            margin-bottom: 5px;
            color: #333;
        }

        input[type="text"],
        input[type="date"],
        input[type="time"],
        input[type="number"],
        input[type="submit"],
        textarea { /* Added textarea */
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #00ab41;
            color: #fff;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #6B6B6B;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Edit Event</h2>
        <?php if (isset($eventName)): ?>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <input type="hidden" name="event_id" value="<?php echo $eventId; ?>">
            <label for="event_name">Event Name:</label><br>
            <input type="text" id="event_name" name="event_name" value="<?php echo $eventName; ?>"><br>
            <label for="event_description">Description:</label><br> <!-- Added description label -->
            <textarea id="event_description" name="event_description"><?php echo $eventDescription; ?></textarea><br> <!-- Added textarea -->
            <label for="start_date">Start Date:</label><br>
            <input type="date" id="start_date" name="start_date" value="<?php echo $startDate; ?>"><br>
            <label for="end_date">End Date:</label><br>
            <input type="date" id="end_date" name="end_date" value="<?php echo $endDate; ?>"><br>
            <label for="start_time">Start Time:</label><br>
            <input type="time" id="start_time" name="start_time" value="<?php echo $startTime; ?>"><br>
            <label for="end_time">End Time:</label><br>
            <input type="time" id="end_time" name="end_time" value="<?php echo $endTime; ?>"><br>
            <label for="volunteers">Number of Volunteers:</label><br>
            <input type="number" id="volunteers" name="volunteers" value="<?php echo $volunteers; ?>"><br>
            <input type="submit" value="Update">
        </form>
        <?php else: ?>
        <p>Event not found.</p>
        <?php endif; ?>
    </div>
</body>
</html>
