<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Include your database connection file
include "../includes/db.php"; // Update this with the correct path to your database connection file

// Get the current volunteer's username
$currentUsername = $_SESSION['username'];

// Query to count the total number of events that the volunteer has not joined
$sqlEvents = "SELECT COUNT(*) AS total_events FROM event WHERE event_id NOT IN (SELECT event_id FROM task WHERE volunteer_username = '$currentUsername')";
$resultEvents = $conn->query($sqlEvents);
$totalEvents = ($resultEvents->num_rows > 0) ? $resultEvents->fetch_assoc()['total_events'] : 0;

// Query to count the total number of notifications
$sqlNotifications = "SELECT COUNT(*) AS total_notifications FROM notifications_v"; // Assuming 'notifications_v' is the name of your notifications table
$resultNotifications = $conn->query($sqlNotifications);
$totalNotifications = ($resultNotifications->num_rows > 0) ? $resultNotifications->fetch_assoc()['total_notifications'] : 0;

// Query to count the total number of tasks for the current volunteer
$sqlTasks = "SELECT COUNT(*) AS total_tasks FROM task WHERE volunteer_username = '$currentUsername'";
$resultTasks = $conn->query($sqlTasks);
$totalTasks = ($resultTasks->num_rows > 0) ? $resultTasks->fetch_assoc()['total_tasks'] : 0;

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Volunteer's Dashboard - Volunteer Management System</title>
    <link rel="stylesheet" href="../css/style2.css"> <!-- Assuming you have a CSS file for styling -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> <!-- Link to Font Awesome for icons -->
    <style>
        /* Your existing CSS styles */
        .container {
            width: 100%;
            margin: 5px auto;
            display: flex;
            flex-direction: row; /* Arrange items horizontally */
        }

        .sidebar {
            flex: 1; /* Take 1/4 of the container */
            background-color: #FFD800; /* Yellow background color */
            color: #000; /* Updated font color */
            padding: 0px;
            font-size: 18px; /* Adjust the font size for sidebar menu */
        }

        .menu {
            list-style-type: none;
            padding: 0px;
        }

        .menu a {
            display: block;
            text-decoration: none;
            color: #000; /* Updated font color */
            padding: 30px;
            border-bottom: 1px solid #555;
            transition: background-color 0.3s ease;
        }

        .menu a:hover {
            background-color: #363636;
            color: #fff;
        }

        .logout-link i {
            margin-right: 5px; /* Add a margin between icon and text */
        }

        .content {
            flex: 3; /* Take 3/4 of the container */
            padding: 20px;
            background-color: #fff;
        }

        h2 {
            color: #000;
            text-align: center;
        }

        .content1 {
            flex: 3; /* Take 3/4 of the container */
            padding-top: 15px;
            margin: 5px;
            background-color: #fff;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        .box {
            width: calc(50% - 60px); /* Set width to half of the container minus margin */
            height: 220px; /* Set height to 220px */
            margin: 10px 0;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            transition: background-color 0.3s ease;
            cursor: pointer;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            position: relative;
        }

        .box:hover {
            background-color: #ddd; /* Darker gray background color on hover */
        }

        .box i {
            font-size: 60px;
            margin-bottom: 10px;
            color: #000;
        }

        .box h3 {
            margin: 0;
            color: #333;
        }

        .box p {
            margin: 5px 0;
            color: #333;
        }

        .box.events {
            background-color: #FF8C00; /* Orange color for events */
        }

        .box.events p {
            position: absolute; /* Position absolute for the total events number */
            top: 5px; /* Adjust top position */
            left: 20px; /* Adjust left position */
            font-size: 36px; /* Adjust font size */
            color: #fff; /* Font color */
            background-color: black; /* Background color */
            padding: 10px 20px; /* Add padding */
            border-radius: 50px; /* Add border radius */
        }

        .box.my-tasks {
            background-color: #00CED1; /* Dark turquoise color for total hours */
        }

        .box.my-tasks p {
            position: absolute; /* Position absolute for the total events number */
            top: 5px; /* Adjust top position */
            left: 20px; /* Adjust left position */
            font-size: 36px; /* Adjust font size */
            color: #fff; /* Font color */
            background-color: black; /* Background color */
            padding: 10px 20px; /* Add padding */
            border-radius: 50px; /* Add border radius */
        }

        .box.notifications {
            background-color: #9932CC; /* Dark orchid color for notifications */
        }

        .box.notifications p.notification-count {
            position: absolute; /* Position absolute for the total notifications count */
            top: 5px; /* Adjust top position */
            left: 20px; /* Adjust left position */
            font-size: 36px; /* Adjust font size */
            color: #fff; /* Font color */
            background-color: black; /* Background color */
            padding: 10px 20px; /* Add padding */
            border-radius: 50px; /* Add border radius */
        }

        .box.profile {
            background-color: #3DED97; /* Gold color for profile */
        }
    </style>
</head>
<body>
<header>
    <h1>Volunteer Management System</h1>
</header>

<div class="container">
    <div class="sidebar">
        <h2>Welcome, <?php echo isset($_SESSION['username']) ? $_SESSION['username'] : "Guest"; ?>!</h2>
        <ul class="menu">
            <li><a href=""><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="events_v.php"><i class="fas fa-calendar"></i> Events</a></li>
            <li><a href="#" onclick="loadMyTasks()"><i class="fas fa-tasks"></i> My Task</a></li>
            <li><a href="#" onclick="loadNotifications()"><i class="fas fa-bell"></i> Notification</a></li>
            <li><a href="#" onclick="loadVolunteerProfile()"><i class="fas fa-user"></i> Profile</a></li>
            <li class="logout-link"><a href="../index.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </div>

    <div class="content" id="dashboardContent">
        <div class="content1">
            <!-- Boxes for Total Events, Total Tasks, Notifications, and Profile -->
            <div class="box events" onclick="location.href='events_v.php';">
                <i class="fas fa-calendar"></i>
                <h3>ALL EVENTS</h3>
                <p><?php echo $totalEvents; ?></p> <!-- Display the total number of events -->
            </div>
            <div class="box my-tasks" href="#" onclick="loadMyTasks()">
                <i class="fas fa-tasks"></i>
                <h3>MY TASKS</h3>
                <p><?php echo $totalTasks; ?></p> <!-- Display the total number of tasks -->
            </div>
            <div class="box notifications" href="#" onclick="loadNotifications()">
                <i class="fas fa-bell"></i>
                <h3>NOTIFICATIONS</h3>
                <p class="notification-count"><?php echo $totalNotifications; ?></p> <!-- Display the total number of notifications -->
            </div>
            <div class="box profile" href="#" onclick="loadVolunteerProfile()">
                <i class="fas fa-user"></i>
                <h3>PROFILE</h3>
            </div>
        </div>
    </div>
</div>

<footer>    
    <p>Volunteer Management System</p>
    <p>This project is developed by Mark Anthony Estopa</p>
</footer>

<!-- JavaScript code -->
<script>
    // Function to load manager profile
    function loadVolunteerProfile() {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("dashboardContent").innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", "volunteer_profile.php", true);
        xhttp.send();
    }

    // Function to load My Tasks
    function loadMyTasks() {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("dashboardContent").innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", "my_tasks.php", true);
        xhttp.send();
    }

    function withdrawTask(taskId) {
        if (confirm("Do you really want to withdraw from this task?")) {
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    // Reload the page to reflect changes
                    window.location.reload();
                }
            };
            xhttp.open("POST", "withdraw_task.php", true);
            xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhttp.send("taskId=" + taskId);
        }
    }
    // Function to load Notifications
    function loadNotifications() {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("dashboardContent").innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", "notifications_v.php", true);
        xhttp.send();
    }
    function closeCommentContainer() {
        var commentContainer = document.querySelector('.floating-container');
        if (commentContainer) {
            document.body.removeChild(commentContainer);
            document.querySelector('.content').classList.remove('disable-event-feed');
            document.querySelector('.sidebar').classList.remove('disable-sidebar');
        }
    }

    // Function to post a comment
    function postComment() {
        var eventId = document.getElementById("eventId").value;
        var comment = document.getElementById("commentInput").value.trim();
        if (comment === "") {
            alert("Please enter a comment.");
            return;
        }

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                // Reload comments section after posting comment
                viewComments(eventId);
                // Close comment container
                closeCommentContainer();
            }
        };
        xhttp.open("POST", "post_comment.php", true);
        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhttp.send("eventId=" + encodeURIComponent(eventId) + "&comment=" + encodeURIComponent(comment));
    }

    // Function to view comments
    function viewComments(eventId) {
        // Close any existing comment containers
        closeCommentContainer();

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                // Display the response in a floating container
                var commentContainer = document.createElement("div");
                commentContainer.className = "floating-container";
                commentContainer.innerHTML = this.responseText;
                document.body.appendChild(commentContainer);
                
                // Add close button functionality
                var closeButton = document.createElement("span");
                closeButton.className = "close-btn";
                closeButton.innerHTML = "&times;";
                closeButton.onclick = closeCommentContainer;
                commentContainer.appendChild(closeButton);
                
                // Disable event feed and sidebar
                document.querySelector('.content').classList.add('disable-event-feed');
                document.querySelector('.sidebar').classList.add('disable-sidebar');
            }
        };
        xhttp.open("GET", "view_comments.php?eventId=" + eventId, true);
        xhttp.send();
    }
    // Function to post a reply
    function postReply(commentId) {
        var replyInput = document.querySelector('.reply-input[data-comment-id="' + commentId + '"]');
        var replyText = replyInput.value.trim();
        if (replyText === "") {
            alert("Please enter a reply.");
            return;
        }

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                // Reload comments section after posting reply
                viewComments(document.getElementById('eventId').value);
                // Clear reply input
                replyInput.value = "";
            }
        };
        xhttp.open("POST", "post_reply.php", true);
        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhttp.send("commentId=" + encodeURIComponent(commentId) + "&reply=" + encodeURIComponent(replyText));
    }
</script>
</body>
</html>
    