// scripts.js

// Example JavaScript code
document.addEventListener('DOMContentLoaded', function() {
    console.log('Scripts loaded successfully.');
    // You can add more JavaScript functionality here as needed
});
