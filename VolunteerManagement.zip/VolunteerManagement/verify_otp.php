<?php
session_start();

// Check if the OTP submitted by the user matches the one stored in the session
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_SESSION['reset_otp'])) {
    $otp_entered = $_POST['otp'];

    if ($otp_entered == $_SESSION['reset_otp']) {
        // OTP is correct, redirect to reset password page
        header("Location: reset_password.php");
        exit();
    } else {
        // OTP is incorrect, display error message
        echo "Invalid OTP. Please try again.";
    }
} else {
    // Invalid request, redirect to forgot password page
    header("Location: forgot_password.php");
    exit();
}
?>
