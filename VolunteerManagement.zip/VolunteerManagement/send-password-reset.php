<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "volunteer_management";

// Create a new connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process password reset logic here
// For example, you might want to fetch the user's email address based on the submitted form data

// Assuming $email is the email address submitted via the form
$email = $_POST['email'];

$token = bin2hex(random_bytes(16));

$token_hash = hash("sha256", $token);

$expiry = date("Y-m-d H:i:s", time() + 60 * 30);

// Now, let's assume you want to send a password reset email to this email address
// You would typically execute a SQL query to fetch user details based on the email address
$sql = "SELECT * FROM volunteers WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($user) {
    // Generate a new token
    $token = bin2hex(random_bytes(32)); // Adjust the token length as needed
    $token_hash = hash("sha256", $token);
    
    // Update the reset_token_hash for the user in the database
    $update_sql = "UPDATE volunteers SET reset_token_hash = ?, reset_token_expires_at = ? WHERE email = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("sss", $token_hash, $expiry, $email);
    $update_stmt->execute();
    
    // Include mailer.php
    require __DIR__ . "/mailer.php";
    
    // Send email
    try {
        $mail->setFrom("choy123@gmail.com", "Your Name");
        $mail->addAddress($email);
        $mail->Subject = "Password Reset";
        $mail->Body = "Click the following link to reset your password: <a href='http://localhost/VolunteerManagement/reset-password.php?token=$token'>Reset Password</a>";
        
        $mail->send();
        echo "Message sent successfully! Please check your inbox.";
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer error: {$mail->ErrorInfo}";
    }
} else {
    echo "User not found.";
}

// Close the database connection
$conn->close();
?>
