-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 22, 2024 at 02:12 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `volunteer_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `id` int(11) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `contact_no` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `volunteers`
--

CREATE TABLE `volunteers` (
  `id` int(11) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contact_no` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `reset_token_hash` varchar(64) DEFAULT NULL,
  `reset_token_expires_at` datetime DEFAULT NULL,
  `is_locked` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `volunteers`
--

INSERT INTO `volunteers` (`id`, `fullname`, `email`, `contact_no`, `username`, `password`, `reset_token_hash`, `reset_token_expires_at`, `is_locked`) VALUES
(24, 'Mark Anthony Estopa', 'estopamark98@gmail.com', 2147483647, 'mark', '$2y$10$UA1e0T8CNnV4qW5fP/wpLe/LAlANedFVaTXMqXjP9Zn4TKAHNSd2C', NULL, NULL, 0),
(29, 'Mark Anthony Estopadasd', 'estopasdsmark98@gmail.com', 2147483647, 'dfjhsd', '$2y$10$WxuMhv5a6C82q5.jFDPtxOdNzZjuPeC1N.QrBC.r3dk9hMxKSyJqS', NULL, NULL, 0),
(34, 'dfsdjhf', 'marksdihf@gmail.com', 2147483647, 'marksa', '$2y$10$VXfunl8r0lMmKWLP.AtIF.wr3jrtmHm6Wze0vARG364JgHkGmDlY2', NULL, NULL, 0),
(35, 'Mark Anthony Estopa', 'dfbsd@gmail.com', 2147483647, 'mark1sa', '$2y$10$J8mvUCBWllR1nGJ4Sr3fOu1KwqWy1QBEjJGwgTrF5AsV1wcIF/83.', NULL, NULL, 0),
(36, 'dfdsfsdfj', 'sdas@gmail.com', 2147483647, 'dfjbsdfkjb', '$2y$10$ljvGLVzaabezEDdHZ1D9au/v/1v1PUSpeEPBApcm5VFm0kA8D6Fna', NULL, NULL, 0),
(38, 'Mark Anthony Estopa', 'estopaasamark98@gmail.com', 2147483647, 'markas', '$2y$10$39NST7e6RYG5aNtNUmpKk.WurTIS1DTz9VBIUYFYAYHFdKW/n7X2m', NULL, NULL, 0),
(39, 'Genard', 'genard@gmail.com', 2147483647, 'genard', '$2y$10$1ec9GF4Hklcqz2y3v107EexeYzdDN70ZsU4g3FIc6pcvFJNCk5/3i', NULL, NULL, 0),
(41, 'ssafsa', 'genardas@gmail.com', 2147483647, 'sfaks', '$2y$10$w.7mRAP/F5MYHE.LvymlwOv1rHjq9BO/0xtea1ivgjzffFNi6vJVe', NULL, NULL, 0),
(43, 'ssafsa', 'genardasas@gmail.com', 2147483647, 'sfaksas', '$2y$10$zElYp2g8hfsQprtvX9Gj3OL/8CQjjadRj2Y5E0RIILcmvzDj6b/1e', NULL, NULL, 0),
(44, 'ssafsa', 'genardaassas@gmail.com', 2147483647, 'sfaksasasa', '$2y$10$Pya6JfEMwl9pyxJRvG7wY.NOQlYTOIesVjBEdku/w6F.G7YpcHDkG', NULL, NULL, 0),
(45, 'dfdsfdsf', 'sdfdsh@gmail.com', 2147483647, 'fgdsfs', '$2y$10$IE4oDMcv/gCCUYSajPdYAOWCSizzgy0UdOMDApbyVuvKarb7gOEHO', NULL, NULL, 0),
(46, 'dcfxsvcv', 'estopamark98@gmail.comsdsad', 2147483647, 'sadassadsad', '$2y$10$3ZL9676Tp7WFHCeWiPKTlOQtaqZxljcdMmfF1wDZJwUuKYAEgkCEi', NULL, NULL, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `manager`
--
ALTER TABLE `manager`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `YES` (`email`);

--
-- Indexes for table `volunteers`
--
ALTER TABLE `volunteers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `UNIQUE` (`email`),
  ADD UNIQUE KEY `reset_token_hash` (`reset_token_hash`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `manager`
--
ALTER TABLE `manager`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `volunteers`
--
ALTER TABLE `volunteers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
